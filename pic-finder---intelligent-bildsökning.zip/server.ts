import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { PIC_FINDER_SYSTEM_PROMPT } from './src/constants/prompt.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Support large image and video uploads up to 50MB
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Initialize GoogleGenAI server-side with User-Agent header
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API route to get app configuration status and the prompt
app.get('/api/config', (_req, res) => {
  res.json({
    hasApiKey: Boolean(apiKey),
    prompt: PIC_FINDER_SYSTEM_PROMPT,
    model: 'gemini-3.8-flash',
  });
});

// Helper to fetch external image or video as base64 with timeout
async function fetchMediaAsBase64(url: string): Promise<{ data: string; mimeType: string }> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)',
        'Accept': '*/*',
      },
    });
    clearTimeout(timeoutId);
    if (!response.ok) {
      throw new Error(`Kunde inte hämta media från URL: ${response.statusText}`);
    }
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const mimeType = response.headers.get('content-type') || 'image/jpeg';
    return {
      data: buffer.toString('base64'),
      mimeType,
    };
  } catch (err: any) {
    clearTimeout(timeoutId);
    throw err;
  }
}

// Helper to parse media category and tags from Gemini response
function extractCategoryAndTags(text: string, mimeType: string): { mediaType: 'photo' | 'video' | 'portrait' | 'screenshot'; rawTags: string } {
  let mediaType: 'photo' | 'video' | 'portrait' | 'screenshot' = 'photo';
  let rawTags = text;

  // If MIME type explicitly denotes video
  if (mimeType.startsWith('video/')) {
    mediaType = 'video';
  }

  // Parse structured "Kategori: [foto | video | porträtt | skärmbild]"
  const categoryMatch = text.match(/kategori:\s*([a-zåäö]+)/i);
  if (categoryMatch) {
    const cat = categoryMatch[1].toLowerCase().trim();
    if (cat.includes('video')) mediaType = 'video';
    else if (cat.includes('portr')) mediaType = 'portrait';
    else if (cat.includes('skärm') || cat.includes('skarm')) mediaType = 'screenshot';
    else if (cat.includes('foto') || cat.includes('bild')) mediaType = 'photo';
  }

  // Parse "Taggar: ..."
  const taggarMatch = text.match(/taggar:\s*([\s\S]+)/i);
  if (taggarMatch) {
    rawTags = taggarMatch[1].trim();
  } else {
    // If no explicit Taggar prefix, strip category line if present
    rawTags = text.replace(/kategori:\s*[a-zåäö]+/i, '').trim();
  }

  return { mediaType, rawTags };
}

// API Route: Analyze Image or Video with Gemini 3.8 Flash
app.post('/api/analyze-image', async (req, res) => {
  try {
    const { imageBase64, mimeType, imageUrl, customPrompt } = req.body;

    let base64Data = imageBase64;
    let finalMimeType = mimeType || 'image/jpeg';

    if (!base64Data && imageUrl) {
      try {
        const fetched = await fetchMediaAsBase64(imageUrl);
        base64Data = fetched.data;
        finalMimeType = fetched.mimeType;
      } catch (err: any) {
        return res.status(400).json({ error: `Misslyckades att hämta media: ${err.message}` });
      }
    }

    if (!base64Data) {
      return res.status(400).json({ error: 'Ingen mediedata skickades med' });
    }

    // Clean base64 header if present (e.g. data:image/png;base64, or data:video/mp4;base64,)
    if (base64Data.includes(';base64,')) {
      const parts = base64Data.split(';base64,');
      const headerMime = parts[0].replace('data:', '');
      if (headerMime) finalMimeType = headerMime;
      base64Data = parts[1];
    }

    const promptText = customPrompt || PIC_FINDER_SYSTEM_PROMPT;

    if (!ai) {
      // Mock fallback if API key is absent in development
      const isVideo = finalMimeType.startsWith('video/');
      const fallbackCat = isVideo ? 'video' : 'photo';
      const fallbackText = isVideo
        ? 'Kategori: video\nTaggar: videoklipp, rörlig bild, semester, utomlands, strand, vågor, sommar, varmt väder, kompisar'
        : 'Kategori: foto\nTaggar: röd ferrari, sportbil, superbil, bil, röd färg, parkerad, asfalt, utomhus, lyxbil, motorfordon, soligt, sommardag';
      const { mediaType, rawTags } = extractCategoryAndTags(fallbackText, finalMimeType);

      return res.json({
        rawText: rawTags,
        detectedMediaType: mediaType,
        fullOutput: fallbackText,
        promptUsed: promptText,
        modelUsed: 'gemini-3.8-flash (demo)',
        warning: 'GEMINI_API_KEY saknas i miljön. Visar exempelrespons.',
      });
    }

    const startTime = Date.now();
    const mediaPart = {
      inlineData: {
        mimeType: finalMimeType,
        data: base64Data,
      },
    };

    const textPart = {
      text: promptText,
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts: [mediaPart, textPart] },
    });

    const elapsedMs = Date.now() - startTime;
    const fullText = response.text?.trim() || '';
    const { mediaType, rawTags } = extractCategoryAndTags(fullText, finalMimeType);

    return res.json({
      rawText: rawTags,
      detectedMediaType: mediaType,
      fullOutput: fullText,
      elapsedMs,
      promptUsed: promptText,
      modelUsed: 'gemini-3.8-flash',
    });
  } catch (error: any) {
    console.error('Error analyzing media with Gemini:', error);
    res.status(500).json({
      error: error.message || 'Ett fel uppstod vid analys av mediet med Gemini.',
    });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`Pic Finder server running at http://localhost:${port}`);
  });
}

startServer();

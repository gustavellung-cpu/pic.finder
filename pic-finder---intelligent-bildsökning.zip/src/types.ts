export type MediaType = 'photo' | 'video' | 'portrait' | 'screenshot';

export interface IndexedMedia {
  id: string;
  title: string;
  url: string;
  thumbnailUrl?: string;
  mediaType: MediaType;
  duration?: number; // For video (seconds)
  rawTagsString: string;
  tags: string[];
  categories: {
    objects: string[];     // Objekt & Fordon
    environment: string[]; // Miljö & Plats
    people: string[];      // Personer & Aktiviteter
    colors: string[];      // Färger, Ljus & Tid
    context: string[];     // Kontext & Stämning
    other: string[];
  };
  visualHash?: string;
  personAttributes?: string[]; // Attributes like "man med skägg", "kvinna i solglasögon", "kompisar"
  indexedAt: string;
  source: 'sample' | 'upload' | 'camera';
  fileSize?: string;
  dimensions?: string;
}

// For backwards compatibility
export type IndexedImage = IndexedMedia;

export interface SearchResult {
  image: IndexedMedia;
  score: number; // 0 to 100
  matchedTags: string[];
  matchReasons: string[];
}

export interface DuplicatePair {
  id: string;
  imageA: IndexedMedia;
  imageB: IndexedMedia;
  similarity: number; // 0 to 100
  reason: string;
}

export interface PersonCluster {
  id: string;
  name: string;
  customName?: string;
  attribute: string;
  avatarUrl: string;
  images: IndexedMedia[];
}

export interface BatchUploadProgress {
  total: number;
  current: number;
  currentFileName: string;
  status: 'idle' | 'uploading' | 'analyzing' | 'complete' | 'error';
  errorMessage?: string;
}

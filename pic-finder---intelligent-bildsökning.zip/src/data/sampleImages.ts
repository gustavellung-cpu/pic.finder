import { IndexedMedia, MediaType } from '../types.js';
import { categorizeTags, parseRawTags } from '../utils/searchEngine.js';

interface RawSample {
  id: string;
  title: string;
  url: string;
  mediaType: MediaType;
  duration?: number;
  rawTags: string;
  source: 'sample';
}

const rawSamples: RawSample[] = [
  {
    id: 'ferrari-street',
    title: 'Röd Ferrari på gatan',
    url: 'https://images.unsplash.com/photo-1583121274602-3e2820c69888?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'röd ferrari, ferrari, sportbil, superbil, bil, röd färg, står framför bil, lyxbil, asfalt, gata, stad, utomhus, soligt, sommardag, motorfordon, blank lack, semester, snabb bil',
    source: 'sample',
  },
  {
    id: 'beach-video',
    title: 'Vågor vid solnedgång (Video)',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4',
    mediaType: 'video',
    duration: 12,
    rawTags: 'video, videoklipp, rörlig bild, vågor, hav, vatten, solnedgång, strand, natur, kväll, gyllene timmen, avkoppling, semester, lugn stämning, utomhus, sommar',
    source: 'sample',
  },
  {
    id: 'portrait-woman',
    title: 'Porträtt: Kvinna i solglasögon',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'portrait',
    rawTags: 'porträtt, kvinna i solglasögon, kvinna, tjej, ansikte, solglasögon, leende, mode, närbild, ljust dagsljus, sommar, snygg stil, utomhus, poserande, person',
    source: 'sample',
  },
  {
    id: 'portrait-beard-man',
    title: 'Porträtt: Man med skägg',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'portrait',
    rawTags: 'porträtt, man med skägg, man, skägg, leende, kille, närbild, ansikte, vänlig blick, studiobelysning, porträttfoto, vardag, person',
    source: 'sample',
  },
  {
    id: 'friends-restaurant',
    title: 'Kompisar på restaurang',
    url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'kompisar, vänner, personer, sitter vid bord, äter mat, dricker vin, restaurang, uteservering, middag, mat, glas, tallrikar, kväll, mysig belysning, semester, fest, skratta, umgänge, sommarkväll',
    source: 'sample',
  },
  {
    id: 'dog-park-video',
    title: 'Hund leker i parken (Video)',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-dog-running-in-the-grass-42777-large.mp4',
    mediaType: 'video',
    duration: 8,
    rawTags: 'video, videoklipp, rörlig video, hund, retriever, springer, leker, gräsmatta, park, träd, utomhus, sommar, grönt gräs, djur, husdjur, glädje, aktivitet, natur',
    source: 'sample',
  },
  {
    id: 'app-screenshot',
    title: 'Skärmbild: Analysdashboard',
    url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'screenshot',
    rawTags: 'skärmbild, skärmdump, app, gränssnitt, dashboard, statistik, diagram, grafer, siffror, datorskärm, digital grafik, ui, analys, mörk bakgrund, kontor, teknik',
    source: 'sample',
  },
  {
    id: 'sunset-beach',
    title: 'Solnedgång vid strand',
    url: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'solnedgång, strand, hav, vågor, sand, sandstrand, tropiskt, utomlands, kväll, gyllene timmen, orange himmel, varmt ljus, avkoppling, semester, lugn, sommar, natur, paradis, blå himmel',
    source: 'sample',
  },
  {
    id: 'winter-cabin',
    title: 'Mysig stuga i vinterberg',
    url: 'https://images.unsplash.com/photo-1517824806704-9040b037703b?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'stuga, trähus, snö, berg, alperna, vinter, granar, skog, snölandskap, ljust, vit snö, blå himmel, vinterdag, skidresa, semester, mysigt, natur, friluftsliv, kallt ljus',
    source: 'sample',
  },
  {
    id: 'cafe-laptop',
    title: 'Kaffekopp och dator vid fönster',
    url: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'laptop, bärbar dator, kaffekopp, kaffe, kopp, bord, fönster, kvinna, sitter vid fönster, dricker kaffe, fikar, café, kafé, inomhus, stad, dagsljus, ljust, morgon, vardag, arbete, lugn stämning',
    source: 'sample',
  },
  {
    id: 'soccer-field',
    title: 'Spelar fotboll på plan',
    url: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'fotboll, fotbollsplan, fotbollsspelare, boll, gräsmatta, sportkläder, spelar fotboll, springer, lag, sport, match, träning, utomhus, dagsljus, soligt, sommar, energi, aktivitet',
    source: 'sample',
  },
  {
    id: 'luxury-pool',
    title: 'Bad och pool på solsemester',
    url: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1200&q=80',
    mediaType: 'photo',
    rawTags: 'pool, simbassäng, solstolar, vatten, turkost vatten, palmer, hotell, badar, simmar, utomhus, soligt, klarblå himmel, semester, sommar, avkoppling, lyx, semesterkänsla',
    source: 'sample',
  },
];

export const INITIAL_SAMPLE_IMAGES: IndexedMedia[] = rawSamples.map(sample => {
  const tags = parseRawTags(sample.rawTags);
  const categories = categorizeTags(tags);
  return {
    id: sample.id,
    title: sample.title,
    url: sample.url,
    thumbnailUrl: sample.url,
    mediaType: sample.mediaType,
    duration: sample.duration,
    rawTagsString: sample.rawTags,
    tags,
    categories,
    indexedAt: new Date(Date.now() - Math.floor(Math.random() * 86400000 * 7)).toISOString(),
    source: 'sample',
  };
});

import React from 'react';
import {
  Image as ImageIcon,
  Search,
  Folder,
  Users,
  Copy,
  Plus,
  Terminal,
  Film,
  User,
  Monitor,
  Sparkles,
  Upload,
} from 'lucide-react';
import { MediaType } from '../types.js';

export type NavTab = 'library' | 'search' | 'albums' | 'people' | 'duplicates';

interface NavigationProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  duplicateCount: number;
  totalItems: number;
  selectedMediaType: MediaType | 'all';
  onSelectMediaType: (type: MediaType | 'all') => void;
  mediaCounts: {
    all: number;
    photo: number;
    video: number;
    portrait: number;
    screenshot: number;
  };
  onOpenUpload: () => void;
  onOpenPrompt: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentTab,
  onSelectTab,
  duplicateCount,
  totalItems,
  selectedMediaType,
  onSelectMediaType,
  mediaCounts,
  onOpenUpload,
  onOpenPrompt,
}) => {
  const navItems: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }[] = [
    { id: 'library', label: 'Bibliotek', icon: ImageIcon, badge: totalItems },
    { id: 'search', label: 'Sök', icon: Search },
    { id: 'albums', label: 'Album', icon: Folder },
    { id: 'people', label: 'Personer', icon: Users },
    { id: 'duplicates', label: 'Dubbletter', icon: Copy, badge: duplicateCount },
  ];

  const mediaShortcuts: { id: MediaType | 'all'; label: string; icon: React.ComponentType<{ className?: string }>; count: number }[] = [
    { id: 'video', label: 'Videor', icon: Film, count: mediaCounts.video },
    { id: 'photo', label: 'Bilder', icon: ImageIcon, count: mediaCounts.photo },
    { id: 'portrait', label: 'Porträtt', icon: User, count: mediaCounts.portrait },
    { id: 'screenshot', label: 'Skärmbilder', icon: Monitor, count: mediaCounts.screenshot },
  ];

  return (
    <>
      {/* =========================================================================
          DESKTOP SIDEBAR (min-width: 769px / md:flex)
          Styled like macOS Apple Photos with glassmorphic dark background
          ========================================================================= */}
      <aside className="hidden md:flex w-64 lg:w-72 bg-slate-950/80 backdrop-blur-2xl border-r border-slate-800/80 flex-col justify-between shrink-0 h-screen sticky top-0 select-none z-30">
        <div className="p-5 space-y-6 overflow-y-auto">
          {/* Brand */}
          <div className="flex items-center gap-3 px-1">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-rose-500/20 shrink-0">
              <ImageIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base tracking-tight text-white">
                  Pic Finder
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  AI
                </span>
              </div>
              <span className="text-[11px] text-slate-400 block -mt-0.5">
                macOS & iOS Galleri
              </span>
            </div>
          </div>

          {/* Primary Navigation (5 choices) */}
          <div className="space-y-1">
            <span className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Foton
            </span>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
                    isActive
                      ? 'bg-rose-500 text-white shadow-md shadow-rose-500/25'
                      : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </div>

                  {typeof item.badge === 'number' && item.badge > 0 && (
                    <span
                      className={`text-[11px] font-mono font-bold px-1.5 py-0.2 rounded-full ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : item.id === 'duplicates'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Mediatyper Shortcuts */}
          <div className="space-y-1 pt-2 border-t border-slate-800/70">
            <span className="px-3 text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-2">
              Mediatyper
            </span>
            {mediaShortcuts.map((sc) => {
              const Icon = sc.icon;
              const isSelected = currentTab === 'library' && selectedMediaType === sc.id;
              return (
                <button
                  key={sc.id}
                  type="button"
                  onClick={() => {
                    onSelectMediaType(sc.id);
                    onSelectTab('library');
                  }}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 text-rose-400 font-semibold border border-slate-700'
                      : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon className="w-3.5 h-3.5" />
                    <span>{sc.label}</span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono">{sc.count}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Sidebar Bottom Actions */}
        <div className="p-4 border-t border-slate-800/80 space-y-2 bg-slate-950/60">
          <button
            type="button"
            onClick={onOpenUpload}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-semibold text-xs shadow-lg shadow-rose-500/20 transition cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span>Ladda upp media</span>
          </button>

          <button
            type="button"
            onClick={onOpenPrompt}
            className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-[11px] font-medium transition cursor-pointer"
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>AI-Prompt & Regler</span>
          </button>
        </div>
      </aside>

      {/* =========================================================================
          MOBILE BOTTOM TAB BAR (max-width: 768px / md:hidden)
          Styled like native iOS Tab Bar with blur effect
          ========================================================================= */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/85 backdrop-blur-2xl border-t border-slate-800/90 px-2 py-1.5 flex items-center justify-around safe-area-bottom shadow-2xl">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition cursor-pointer relative ${
                isActive ? 'text-rose-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
                {item.id === 'duplicates' && duplicateCount > 0 && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 ring-2 ring-slate-950 absolute -top-0.5 -right-0.5" />
                )}
              </div>
              <span className={`text-[10px] mt-1 font-medium ${isActive ? 'font-bold' : ''}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </>
  );
};

import React, { useRef, useState } from 'react';
import { Eye, Copy, Check, Sparkles, Film, User, Monitor, Play } from 'lucide-react';
import { SearchResult } from '../types.js';

interface ImageCardProps {
  result: SearchResult;
  isSearching: boolean;
  onSelect: () => void;
  onTagClick: (tag: string) => void;
}

export const ImageCard: React.FC<ImageCardProps> = ({
  result,
  isSearching,
  onSelect,
  onTagClick,
}) => {
  const { image, score, matchedTags, matchReasons } = result;
  const [copied, setCopied] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleCopyTags = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(image.rawTagsString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
    if (image.mediaType === 'video' && videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    if (image.mediaType === 'video' && videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  };

  // Color code matching score
  const getScoreBadge = () => {
    if (!isSearching) return null;
    let bg = 'from-emerald-600 to-teal-600 text-white border-emerald-400/40';
    if (score < 50) bg = 'from-amber-600 to-orange-600 text-white border-amber-400/40';
    else if (score < 80) bg = 'from-cyan-600 to-blue-600 text-white border-cyan-400/40';

    return (
      <div className={`flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded-full text-[10px] sm:text-xs font-bold bg-gradient-to-r ${bg} shadow-md border`}>
        <Sparkles className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
        <span>{score}%</span>
      </div>
    );
  };

  const getMediaTypeBadge = () => {
    switch (image.mediaType) {
      case 'video':
        return (
          <span className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] font-semibold bg-rose-600/90 text-white backdrop-blur-md border border-rose-400/30 shadow">
            <Film className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
            <span className="hidden sm:inline">Video</span> {image.duration ? `${image.duration}s` : ''}
          </span>
        );
      case 'portrait':
        return (
          <span className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] font-semibold bg-blue-600/90 text-white backdrop-blur-md border border-blue-400/30 shadow">
            <User className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
            <span className="hidden sm:inline">Porträtt</span>
          </span>
        );
      case 'screenshot':
        return (
          <span className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] sm:text-[10px] font-semibold bg-purple-600/90 text-white backdrop-blur-md border border-purple-400/30 shadow">
            <Monitor className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
            <span className="hidden sm:inline">Skärm</span>
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onSelect}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect();
        }
      }}
      aria-label={`Visa detaljer för ${image.title}`}
      className="group relative flex flex-col bg-slate-900/90 hover:bg-slate-900 border border-slate-800/80 hover:border-slate-700 rounded-xl sm:rounded-2xl overflow-hidden transition-all duration-200 hover:shadow-xl hover:shadow-black/60 cursor-pointer text-left focus:outline-none focus:ring-2 focus:ring-rose-500"
    >
      {/* Square Media Container with Badges */}
      <div className="relative aspect-square w-full overflow-hidden bg-black">
        {image.mediaType === 'video' ? (
          <div className="relative w-full h-full">
            <video
              ref={videoRef}
              src={image.url}
              muted
              playsInline
              loop
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            {!isHovered && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-black/60 backdrop-blur-sm border border-white/20 flex items-center justify-center text-white">
                  <Play className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-white translate-x-0.5" />
                </div>
              </div>
            )}
          </div>
        ) : (
          <img
            src={image.url}
            alt={image.title}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}

        {/* Top Badges */}
        <div className="absolute top-1.5 left-1.5 right-1.5 sm:top-2 sm:left-2 sm:right-2 flex items-center justify-between gap-1 pointer-events-none z-10">
          <div>{getScoreBadge()}</div>
          <div className="flex items-center gap-1 ml-auto">
            {getMediaTypeBadge()}
          </div>
        </div>

        {/* Hover Quick Actions Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2 sm:p-3 justify-between z-10">
          <span className="text-[10px] sm:text-xs font-semibold text-white flex items-center gap-1">
            <Eye className="w-3 h-3" /> Visa
          </span>
          <button
            type="button"
            onClick={handleCopyTags}
            title="Kopiera alla taggar"
            className="p-1 sm:p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-900 text-slate-200 hover:text-white border border-slate-700 backdrop-blur-sm transition pointer-events-auto"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
          </button>
        </div>
      </div>

      {/* Card Details */}
      <div className="p-2 sm:p-3 flex-1 flex flex-col justify-between space-y-1 sm:space-y-2">
        <div>
          <h3 className="font-semibold text-slate-100 text-[11px] sm:text-xs md:text-sm line-clamp-1 group-hover:text-rose-400 transition-colors">
            {image.title}
          </h3>

          {/* Match Reason if searching */}
          {isSearching && matchReasons.length > 0 && (
            <p className="text-[10px] sm:text-[11px] text-emerald-400 font-medium mt-0.5 flex items-center gap-1 line-clamp-1">
              <Sparkles className="w-2.5 h-2.5 shrink-0" />
              <span className="truncate">{matchReasons[0]}</span>
            </p>
          )}
        </div>

        {/* Tags / Keywords Cloud - Compact on mobile */}
        <div className="flex flex-wrap gap-1 pt-0.5">
          {image.tags.slice(0, 3).map((tag) => {
            const isMatched = matchedTags.some(
              (m) => m.toLowerCase() === tag.toLowerCase()
            );
            return (
              <span
                key={tag}
                onClick={(e) => {
                  e.stopPropagation();
                  onTagClick(tag);
                }}
                className={`text-[9px] sm:text-[10px] px-1.5 py-0.2 rounded font-medium transition cursor-pointer border truncate max-w-[80px] sm:max-w-none ${
                  isMatched
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-semibold'
                    : 'bg-slate-800 text-slate-400 border-slate-700/60 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {tag}
              </span>
            );
          })}
        </div>
      </div>
    </div>
  );
};

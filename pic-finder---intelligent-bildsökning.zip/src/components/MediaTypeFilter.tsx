import React from 'react';
import { Film, Image as ImageIcon, User, Monitor, Layers } from 'lucide-react';
import { MediaType } from '../types.js';

interface MediaTypeFilterProps {
  selectedMediaType: MediaType | 'all';
  onSelectMediaType: (type: MediaType | 'all') => void;
  counts: {
    all: number;
    photo: number;
    video: number;
    portrait: number;
    screenshot: number;
  };
}

export const MediaTypeFilter: React.FC<MediaTypeFilterProps> = ({
  selectedMediaType,
  onSelectMediaType,
  counts,
}) => {
  const buttons: { id: MediaType | 'all'; label: string; icon: React.ComponentType<{ className?: string }>; count: number }[] = [
    { id: 'all', label: 'Alla medier', icon: Layers, count: counts.all },
    { id: 'video', label: 'Videor', icon: Film, count: counts.video },
    { id: 'photo', label: 'Bilder', icon: ImageIcon, count: counts.photo },
    { id: 'portrait', label: 'Porträtt', icon: User, count: counts.portrait },
    { id: 'screenshot', label: 'Skärmbilder', icon: Monitor, count: counts.screenshot },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto flex items-center justify-center p-1 bg-slate-900/90 border border-slate-800 rounded-2xl shadow-inner overflow-x-auto scrollbar-none">
      <div className="flex items-center gap-1 w-full justify-between sm:justify-center">
        {buttons.map((btn) => {
          const Icon = btn.icon;
          const isActive = selectedMediaType === btn.id;
          return (
            <button
              key={btn.id}
              type="button"
              onClick={() => onSelectMediaType(btn.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap ${
                isActive
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{btn.label}</span>
              <span
                className={`text-[11px] px-1.5 py-0.2 rounded-full font-mono ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {btn.count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

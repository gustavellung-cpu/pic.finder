import React from 'react';
import { Car, Trees, Users, Sunset, Sparkles, Layers } from 'lucide-react';
import { IndexedImage } from '../types.js';

interface CategoryFilterProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onSelectTag: (tag: string) => void;
  images: IndexedImage[];
}

export const CATEGORIES = [
  { id: 'all', label: 'Alla kategorier', icon: Layers, color: 'text-slate-300' },
  { id: 'objects', label: 'Objekt & Fordon', icon: Car, color: 'text-rose-400', key: 'objects' as const },
  { id: 'environment', label: 'Miljö & Plats', icon: Trees, color: 'text-emerald-400', key: 'environment' as const },
  { id: 'people', label: 'Personer & Aktiviteter', icon: Users, color: 'text-blue-400', key: 'people' as const },
  { id: 'colors', label: 'Färger, Ljus & Tid', icon: Sunset, color: 'text-amber-400', key: 'colors' as const },
  { id: 'context', label: 'Kontext & Stämning', icon: Sparkles, color: 'text-purple-400', key: 'context' as const },
];

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  onSelectCategory,
  onSelectTag,
  images,
}) => {
  // Collect top tags for the active category
  const activeTags = React.useMemo(() => {
    if (selectedCategory === 'all') {
      // Collect top 12 overall tags
      const counts: Record<string, number> = {};
      images.forEach((img) => {
        img.tags.forEach((t) => {
          counts[t] = (counts[t] || 0) + 1;
        });
      });
      return Object.entries(counts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 14)
        .map(([t]) => t);
    }

    const catObj = CATEGORIES.find((c) => c.id === selectedCategory);
    if (!catObj || !catObj.key) return [];

    const counts: Record<string, number> = {};
    images.forEach((img) => {
      const list = img.categories[catObj.key] || [];
      list.forEach((t) => {
        counts[t] = (counts[t] || 0) + 1;
      });
    });

    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 14)
      .map(([t]) => t);
  }, [selectedCategory, images]);

  return (
    <div className="w-full max-w-7xl mx-auto space-y-3">
      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none text-xs sm:text-sm">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl whitespace-nowrap font-medium transition cursor-pointer border ${
                isSelected
                  ? 'bg-slate-700 text-white border-slate-500 shadow-md ring-1 ring-slate-400/30'
                  : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:bg-slate-800 hover:text-slate-200'
              }`}
            >
              <Icon className={`w-4 h-4 ${cat.color}`} />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Relevant Subtags for the selected category */}
      {activeTags.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400 pt-1">
          <span className="font-medium mr-1 text-slate-500">Snabbfilter:</span>
          {activeTags.map((tag) => (
            <button
              key={tag}
              type="button"
              onClick={() => onSelectTag(tag)}
              className="px-2 py-0.5 rounded-md bg-slate-800/90 hover:bg-rose-500/20 hover:text-rose-300 hover:border-rose-500/40 border border-slate-700/60 text-slate-300 transition cursor-pointer"
            >
              #{tag}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Upload,
  Camera,
  Sparkles,
  AlertCircle,
  Loader2,
  Film,
  Image as ImageIcon,
  CheckCircle2,
  User,
  Monitor,
} from 'lucide-react';
import { IndexedMedia, MediaType } from '../types.js';
import { parseRawTags, categorizeTags } from '../utils/searchEngine.js';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImagesIndexed: (images: IndexedMedia[]) => void;
}

interface QueueItem {
  file: File;
  name: string;
  size: number;
  isVideo: boolean;
}

// Quick presets for test media
const QUICK_TEST_PRESETS = [
  {
    name: 'Vågor vid solnedgång (Video)',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4',
    mediaType: 'video' as MediaType,
    duration: 12,
    description: 'Testa video-analys med rörliga vågor',
  },
  {
    name: 'Kvinna i solglasögon (Porträtt)',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1000&q=80',
    mediaType: 'portrait' as MediaType,
    description: 'Testa personporträtt och ansiktsattribut',
  },
  {
    name: 'App Dashboard (Skärmbild)',
    url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1000&q=80',
    mediaType: 'screenshot' as MediaType,
    description: 'Testa skärmbild och UI-analys',
  },
  {
    name: 'Röd Ferrari GT (Foto)',
    url: 'https://images.unsplash.com/photo-1592198084033-aade902d1aae?auto=format&fit=crop&w=1000&q=80',
    mediaType: 'photo' as MediaType,
    description: 'Testa fordons- och miljöfoto',
  },
];

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onImagesIndexed,
}) => {
  const [mode, setMode] = useState<'upload' | 'camera' | 'presets'>('upload');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressInfo, setProgressInfo] = useState<{
    current: number;
    total: number;
    currentFileName: string;
    step: string;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Camera state
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);

  // Drag and drop state
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  if (!isOpen) return null;

  const startCamera = async () => {
    try {
      setError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setIsCameraActive(true);
    } catch (err: any) {
      setError('Kunde inte få åtkomst till kameran: ' + (err.message || 'Kontrollera behörigheter'));
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setIsCameraActive(false);
  };

  const capturePhoto = async () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    stopCamera();

    // Process captured photo immediately
    await processSingleItem(dataUrl, 'image/jpeg', 'Foto taget med kamera', 'portrait', 'camera');
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    processFiles(Array.from(files));
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processFiles(Array.from(files));
    }
  };

  // Convert File to base64
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  };

  // Process a batch of files sequentially with live progress UI
  const processFiles = async (files: File[]) => {
    setError(null);
    setIsProcessing(true);
    const newIndexedItems: IndexedMedia[] = [];

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const isVideo = file.type.startsWith('video/');
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        const title = cleanName.charAt(0).toUpperCase() + cleanName.slice(1);

        setProgressInfo({
          current: i + 1,
          total: files.length,
          currentFileName: file.name,
          step: isVideo
            ? `Förbereder och analyserar video med Gemini...`
            : `Läser in och analyserar med Gemini...`,
        });

        const base64Data = await fileToBase64(file);

        setProgressInfo({
          current: i + 1,
          total: files.length,
          currentFileName: file.name,
          step: `Gemini analyserar mediainnehåll och extraherar semantiska taggar...`,
        });

        const res = await fetch('/api/analyze-image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Data,
            mimeType: file.type,
          }),
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || `Kunde inte analysera ${file.name}`);
        }

        const data = await res.json();
        const rawTags = data.rawText || '';
        const tags = parseRawTags(rawTags);
        const categories = categorizeTags(tags);
        const detectedType: MediaType = data.detectedMediaType || (isVideo ? 'video' : 'photo');

        const newMedia: IndexedMedia = {
          id: 'media-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
          title,
          url: base64Data,
          thumbnailUrl: base64Data,
          mediaType: detectedType,
          rawTagsString: rawTags,
          tags,
          categories,
          indexedAt: new Date().toISOString(),
          source: 'upload',
        };

        newIndexedItems.push(newMedia);
      }

      onImagesIndexed(newIndexedItems);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Fel under batch-uppladdning');
    } finally {
      setIsProcessing(false);
      setProgressInfo(null);
    }
  };

  // Helper for single preset or camera item
  const processSingleItem = async (
    mediaUrl: string,
    mimeType: string,
    title: string,
    preferredType: MediaType,
    source: 'upload' | 'camera' | 'sample'
  ) => {
    setIsProcessing(true);
    setError(null);
    setProgressInfo({
      current: 1,
      total: 1,
      currentFileName: title,
      step: 'Analyserar media och kategoriserar med Gemini...',
    });

    try {
      const isBase64 = mediaUrl.startsWith('data:');
      const payload: any = {
        mimeType,
      };

      if (isBase64) {
        payload.imageBase64 = mediaUrl;
      } else {
        payload.imageUrl = mediaUrl;
      }

      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Serverfel vid Gemini-analys');
      }

      const data = await res.json();
      const rawTags = data.rawText || '';
      const tags = parseRawTags(rawTags);
      const categories = categorizeTags(tags);
      const detectedType: MediaType = data.detectedMediaType || preferredType;

      const newMedia: IndexedMedia = {
        id: 'media-' + Date.now(),
        title,
        url: mediaUrl,
        thumbnailUrl: mediaUrl,
        mediaType: detectedType,
        rawTagsString: rawTags,
        tags,
        categories,
        indexedAt: new Date().toISOString(),
        source,
      };

      onImagesIndexed([newMedia]);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Kunde inte indexera mediet');
    } finally {
      setIsProcessing(false);
      setProgressInfo(null);
    }
  };

  const handlePresetSelect = (preset: typeof QUICK_TEST_PRESETS[0]) => {
    const mime = preset.mediaType === 'video' ? 'video/mp4' : 'image/jpeg';
    processSingleItem(preset.url, mime, preset.name, preset.mediaType, 'upload');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="upload-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-sm overflow-y-auto"
      onClick={() => {
        if (!isProcessing) {
          stopCamera();
          onClose();
        }
      }}
    >
      <div
        className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto text-slate-100 flex flex-col p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 id="upload-modal-title" className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-rose-400" />
              Ladda upp & indexera (Bilder & Videor)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Stöder enstaka filer och stora batcher med automatisk mediaklassificering (video, porträtt, skärmbild, foto).
            </p>
          </div>
          {!isProcessing && (
            <button
              type="button"
              onClick={() => {
                stopCamera();
                onClose();
              }}
              aria-label="Stäng uppladdningsruta"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Tab selection */}
        {!isProcessing && (
          <div className="flex rounded-xl bg-slate-800/80 p-1 border border-slate-700/60 text-xs font-semibold">
            <button
              type="button"
              onClick={() => {
                stopCamera();
                setMode('upload');
              }}
              className={`flex-1 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'upload' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Bilder & Videor (Batch)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('camera');
                startCamera();
              }}
              className={`flex-1 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'camera' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Kamera</span>
            </button>
            <button
              type="button"
              onClick={() => {
                stopCamera();
                setMode('presets');
              }}
              className={`flex-1 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
                mode === 'presets' ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Snabbval</span>
            </button>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Batch Progress UI */}
        {isProcessing && progressInfo && (
          <div className="p-6 rounded-2xl bg-slate-800/90 border border-rose-500/40 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-rose-400 font-semibold text-sm">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>
                  Analyserar {progressInfo.current} av {progressInfo.total}: {progressInfo.currentFileName}
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-slate-300 bg-slate-900 px-2.5 py-1 rounded-full border border-slate-700">
                {Math.round((progressInfo.current / progressInfo.total) * 100)}%
              </span>
            </div>

            {/* Animated Progress Bar */}
            <div className="w-full bg-slate-900 rounded-full h-2.5 overflow-hidden border border-slate-700">
              <div
                className="bg-gradient-to-r from-rose-500 via-amber-500 to-emerald-400 h-full transition-all duration-300"
                style={{ width: `${(progressInfo.current / progressInfo.total) * 100}%` }}
              />
            </div>

            <p className="text-xs text-slate-400 italic">
              {progressInfo.step}
            </p>
          </div>
        )}

        {/* Mode content */}
        {!isProcessing && mode === 'camera' && (
          <div className="space-y-4">
            <div className="relative aspect-video rounded-xl bg-black overflow-hidden border border-slate-700 flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              {!isCameraActive && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
                  <Camera className="w-8 h-8 text-slate-500 mb-2 animate-bounce" />
                  <p className="text-xs text-slate-400">Startar kamera...</p>
                </div>
              )}
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={stopCamera}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Avbryt
              </button>
              <button
                type="button"
                onClick={capturePhoto}
                disabled={!isCameraActive}
                className="flex items-center gap-2 px-5 py-2 rounded-xl text-xs font-semibold bg-rose-500 hover:bg-rose-600 text-white transition disabled:opacity-50 cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>Ta bild & analysera</span>
              </button>
            </div>
          </div>
        )}

        {!isProcessing && mode === 'presets' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {QUICK_TEST_PRESETS.map((p) => (
              <button
                key={p.name}
                type="button"
                onClick={() => handlePresetSelect(p)}
                className="flex flex-col text-left p-3 rounded-xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-rose-500/50 transition cursor-pointer group"
              >
                <div className="aspect-video w-full rounded-lg overflow-hidden bg-black mb-2 relative">
                  {p.mediaType === 'video' ? (
                    <video
                      src={p.url}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      muted
                      loop
                      playsInline
                    />
                  ) : (
                    <img
                      src={p.url}
                      alt={p.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  )}
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold bg-black/60 text-white backdrop-blur-sm">
                    {p.mediaType.toUpperCase()}
                  </span>
                </div>
                <span className="font-semibold text-xs text-white group-hover:text-rose-400 transition-colors">
                  {p.name}
                </span>
                <span className="text-[11px] text-slate-400">{p.description}</span>
              </button>
            ))}
          </div>
        )}

        {!isProcessing && mode === 'upload' && (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center text-center cursor-pointer transition ${
              isDragging
                ? 'border-rose-400 bg-rose-500/10'
                : 'border-slate-700 hover:border-slate-500 bg-slate-800/40 hover:bg-slate-800/70'
            }`}
          >
            {/* Multiple files and accept image/* and video/* */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              multiple
              className="hidden"
              onChange={handleFileChange}
            />
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mb-3 text-rose-400">
              <Upload className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-white">
              Klicka eller dra och släpp filer här
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Stöder både <strong>Bilder</strong> (JPG, PNG, WebP) och <strong>Videor</strong> (MP4, WebM) • Flervalsstöd (Batch)
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

import React from 'react';
import {
  X,
  Copy,
  Check,
  RefreshCw,
  Car,
  Trees,
  Users,
  Sunset,
  Sparkles,
  Calendar,
  Layers,
  Search,
  Film,
  User,
  Monitor,
  Camera,
} from 'lucide-react';
import { IndexedMedia } from '../types.js';

interface ImageDetailModalProps {
  image: IndexedMedia | null;
  onClose: () => void;
  onSearchTag: (tag: string) => void;
  onReindex: (image: IndexedMedia) => Promise<void>;
  isReindexing: boolean;
}

export const ImageDetailModal: React.FC<ImageDetailModalProps> = ({
  image,
  onClose,
  onSearchTag,
  onReindex,
  isReindexing,
}) => {
  const [copiedRaw, setCopiedRaw] = React.useState(false);

  if (!image) return null;

  const handleCopyRaw = () => {
    navigator.clipboard.writeText(image.rawTagsString);
    setCopiedRaw(true);
    setTimeout(() => setCopiedRaw(false), 2000);
  };

  const getMediaBadge = () => {
    switch (image.mediaType) {
      case 'video':
        return { label: 'Video', icon: Film, color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' };
      case 'portrait':
        return { label: 'Porträtt', icon: User, color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' };
      case 'screenshot':
        return { label: 'Skärmbild', icon: Monitor, color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' };
      default:
        return { label: 'Foto', icon: Camera, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' };
    }
  };

  const badge = getMediaBadge();
  const BadgeIcon = badge.icon;

  const categorySections = [
    {
      title: 'Objekt & Fordon',
      icon: Car,
      color: 'text-rose-400 bg-rose-500/10 border-rose-500/20',
      items: image.categories.objects,
    },
    {
      title: 'Miljö & Plats',
      icon: Trees,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
      items: image.categories.environment,
    },
    {
      title: 'Personer & Aktiviteter',
      icon: Users,
      color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
      items: image.categories.people,
    },
    {
      title: 'Färger, Ljus & Tid',
      icon: Sunset,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
      items: image.categories.colors,
    },
    {
      title: 'Kontext & Stämning',
      icon: Sparkles,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
      items: image.categories.context,
    },
    {
      title: 'Övriga nyckelord',
      icon: Layers,
      color: 'text-slate-400 bg-slate-500/10 border-slate-500/20',
      items: image.categories.other,
    },
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="image-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto text-slate-100 flex flex-col md:flex-row max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Stäng bilddetaljer"
          className="absolute top-3 right-3 z-20 p-2 rounded-full bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-600/50 backdrop-blur-md transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Left Side: Media (Image or Video) */}
        <div className="w-full md:w-1/2 bg-black flex items-center justify-center relative min-h-[260px] md:min-h-full">
          {image.mediaType === 'video' ? (
            <video
              src={image.url}
              controls
              autoPlay
              playsInline
              className="w-full h-full max-h-[40vh] md:max-h-[90vh] object-contain"
            />
          ) : (
            <img
              src={image.url}
              alt={image.title}
              className="w-full h-full max-h-[40vh] md:max-h-[90vh] object-contain"
            />
          )}
        </div>

        {/* Right Side: Metadata and Categorized Tags */}
        <div className="w-full md:w-1/2 p-5 sm:p-6 flex flex-col overflow-y-auto space-y-5">
          {/* Header Info */}
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1.5 flex-wrap">
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md font-semibold text-[11px] border ${badge.color}`}>
                <BadgeIcon className="w-3 h-3" />
                <span>{badge.label}</span>
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                {new Date(image.indexedAt).toLocaleDateString('sv-SE')}
              </span>
              <span>•</span>
              <span className="capitalize">{image.source}</span>
            </div>
            <h2 id="image-modal-title" className="text-xl font-bold text-white">
              {image.title}
            </h2>
          </div>

          {/* Re-index Action */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={isReindexing}
              onClick={() => onReindex(image)}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 transition cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-rose-400 ${isReindexing ? 'animate-spin' : ''}`} />
              <span>{isReindexing ? 'Analyserar med Gemini...' : 'Kör om AI-analys'}</span>
            </button>
            <button
              type="button"
              onClick={handleCopyRaw}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/60 text-slate-300 transition cursor-pointer"
            >
              {copiedRaw ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedRaw ? 'Kopierat!' : 'Kopiera taggar'}</span>
            </button>
          </div>

          {/* Categorized Semantic Tags */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Semantiska kategorier ({image.tags.length} taggar)
            </h3>

            <div className="space-y-3">
              {categorySections.map((sec) => {
                if (sec.items.length === 0) return null;
                const Icon = sec.icon;
                return (
                  <div key={sec.title} className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 space-y-2">
                    <div className="flex items-center gap-2 text-xs font-semibold">
                      <Icon className="w-3.5 h-3.5" />
                      <span>{sec.title}</span>
                      <span className="text-slate-500 font-normal">({sec.items.length})</span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {sec.items.map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            onSearchTag(tag);
                            onClose();
                          }}
                          className={`text-xs px-2.5 py-1 rounded-lg border transition cursor-pointer flex items-center gap-1 ${sec.color} hover:brightness-125`}
                        >
                          <Search className="w-2.5 h-2.5 opacity-60" />
                          <span>{tag}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Raw AI Response Container */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-semibold text-slate-400">
                Rå kommaseparerad representation:
              </span>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 font-mono break-words leading-relaxed select-all">
              "{image.rawTagsString}"
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

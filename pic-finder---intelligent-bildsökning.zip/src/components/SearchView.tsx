import React from 'react';
import { Search, Sparkles, ImageOff } from 'lucide-react';
import { IndexedMedia, SearchResult } from '../types.js';
import { SearchBar } from './SearchBar.js';
import { ImageCard } from './ImageCard.js';

interface SearchViewProps {
  query: string;
  setQuery: (q: string) => void;
  results: SearchResult[];
  totalCount: number;
  onSelectItem: (item: IndexedMedia) => void;
  onTagClick: (tag: string) => void;
}

export const SearchView: React.FC<SearchViewProps> = ({
  query,
  setQuery,
  results,
  totalCount,
  onSelectItem,
  onTagClick,
}) => {
  return (
    <section className="view view-search space-y-6 animate-fade-in">
      <div className="space-y-4 text-center max-w-3xl mx-auto pt-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>Semantisk flerspråkig AI-sökning</span>
        </div>
        <h2 className="text-xl sm:text-3xl font-extrabold text-white tracking-tight">
          Sök efter ögonblick med naturligt språk
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-lg mx-auto">
          Beskriv situationen, personerna, fordonen eller stämningen på svenska.
        </p>

        <SearchBar
          query={query}
          setQuery={setQuery}
          resultCount={results.length}
          totalCount={totalCount}
          onClear={() => setQuery('')}
        />
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-800/80 pt-3">
        <span>
          Visar <strong>{results.length}</strong> av {totalCount} resultat
        </span>
        {query && (
          <span className="text-rose-400 font-medium truncate max-w-xs">
            Träffar för "{query}"
          </span>
        )}
      </div>

      {/* Responsive Gallery Grid: 3 columns on mobile, dynamic 5-8 columns on desktop */}
      {results.length > 0 ? (
        <div className="grid grid-cols-3 md:grid-cols-[repeat(auto-fill,minmax(170px,1fr))] gap-1.5 sm:gap-3 lg:gap-4">
          {results.map((result) => (
            <ImageCard
              key={result.image.id}
              result={result}
              isSearching={Boolean(query.trim())}
              onSelect={() => onSelectItem(result.image)}
              onTagClick={onTagClick}
            />
          ))}
        </div>
      ) : (
        <div className="py-16 text-center rounded-2xl bg-slate-900/40 border border-slate-800 max-w-md mx-auto p-6 space-y-3">
          <ImageOff className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-semibold text-white">Inga träffar hittades</h3>
          <p className="text-xs text-slate-400">
            Försök med andra ord, t.ex. "bil", "restaurang", "strand", "kvinna" eller klicka på något av snabbförslagen ovanför.
          </p>
        </div>
      )}
    </section>
  );
};

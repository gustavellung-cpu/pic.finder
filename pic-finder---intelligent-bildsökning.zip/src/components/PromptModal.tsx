import React, { useState } from 'react';
import { X, Copy, Check, Terminal, FileCode, CheckCircle2 } from 'lucide-react';
import { PIC_FINDER_SYSTEM_PROMPT } from '../constants/prompt.js';

interface PromptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PromptModal: React.FC<PromptModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(PIC_FINDER_SYSTEM_PROMPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="prompt-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-auto text-slate-100 flex flex-col p-6 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h2 id="prompt-modal-title" className="text-base font-bold text-white">
                Pic Finder Systemprompt & Regler
              </h2>
              <p className="text-xs text-slate-400">
                Instruktionen som skickas till Gemini 3.8 Flash Vision
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Stäng promptfönster"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Categories summary */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700">
            <span className="font-semibold text-rose-400 block">1. Objekt & Fordon</span>
            <span className="text-[11px] text-slate-400">röd Ferrari, hund, kaffekopp</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700">
            <span className="font-semibold text-emerald-400 block">2. Miljö & Plats</span>
            <span className="text-[11px] text-slate-400">strand, restaurang, utomhus</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700">
            <span className="font-semibold text-blue-400 block">3. Personer & Aktiviteter</span>
            <span className="text-[11px] text-slate-400">kompisar, äter, står framför bil</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700">
            <span className="font-semibold text-amber-400 block">4. Färger, Ljus & Tid</span>
            <span className="text-[11px] text-slate-400">solnedgång, ljust, kväll</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700">
            <span className="font-semibold text-purple-400 block">5. Kontext & Stämning</span>
            <span className="text-[11px] text-slate-400">semester, fest, vardag, sommar</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700">
            <span className="font-semibold text-teal-400 block">Strikta regler</span>
            <span className="text-[11px] text-slate-400">Enbart komma-lista på svenska</span>
          </div>
        </div>

        {/* Prompt code block */}
        <div className="relative">
          <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-80 select-all">
            {PIC_FINDER_SYSTEM_PROMPT}
          </pre>
          <button
            type="button"
            onClick={handleCopy}
            className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 backdrop-blur-sm transition cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Kopierat' : 'Kopiera prompt'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { User, Users, Edit3, Check, X, ArrowLeft, Sparkles } from 'lucide-react';
import { IndexedMedia, PersonCluster } from '../types.js';
import { groupImagesByPerson } from '../utils/personGrouper.js';
import { ImageCard } from './ImageCard.js';

interface PersonAlbumsViewProps {
  items: IndexedMedia[];
  onSelectImage: (item: IndexedMedia) => void;
  onTagClick: (tag: string) => void;
}

export const PersonAlbumsView: React.FC<PersonAlbumsViewProps> = ({
  items,
  onSelectImage,
  onTagClick,
}) => {
  const [customNames, setCustomNames] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('pic_finder_person_names');
      return saved ? JSON.parse(saved) : {};
    } catch (e) {
      return {};
    }
  });

  const [editingPersonId, setEditingPersonId] = useState<string | null>(null);
  const [editInput, setEditInput] = useState('');
  const [selectedCluster, setSelectedCluster] = useState<PersonCluster | null>(null);

  // Derive clusters from items
  const clusters = React.useMemo(() => {
    const raw = groupImagesByPerson(items);
    return raw.map((c) => ({
      ...c,
      name: customNames[c.id] || c.name,
    }));
  }, [items, customNames]);

  const handleStartEdit = (cluster: PersonCluster, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingPersonId(cluster.id);
    setEditInput(cluster.name);
  };

  const handleSaveEdit = (clusterId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (editInput.trim()) {
      const updated = { ...customNames, [clusterId]: editInput.trim() };
      setCustomNames(updated);
      try {
        localStorage.setItem('pic_finder_person_names', JSON.stringify(updated));
      } catch (err) {
        console.warn(err);
      }
    }
    setEditingPersonId(null);
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingPersonId(null);
  };

  // If a cluster is opened in drill-down mode
  if (selectedCluster) {
    const current = clusters.find((c) => c.id === selectedCluster.id) || selectedCluster;
    return (
      <section className="view view-people space-y-6 animate-fade-in">
        {/* Back navigation */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <button
            type="button"
            onClick={() => setSelectedCluster(null)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Alla personer</span>
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-rose-500 shadow-md shrink-0">
              <img
                src={current.avatarUrl}
                alt={current.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white">{current.name}</h2>
              <p className="text-[11px] text-slate-400">{current.images.length} mediefiler</p>
            </div>
          </div>
        </div>

        {/* Media Grid: 3 columns on mobile, dynamic 5-8 columns on desktop */}
        <div className="grid grid-cols-3 md:grid-cols-[repeat(auto-fill,minmax(170px,1fr))] gap-1.5 sm:gap-3 lg:gap-4">
          {current.images.map((item) => (
            <ImageCard
              key={item.id}
              result={{
                image: item,
                score: 100,
                matchedTags: [current.attribute],
                matchReasons: [`Identifierad som ${current.name}`],
              }}
              isSearching={false}
              onSelect={() => onSelectImage(item)}
              onTagClick={onTagClick}
            />
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="view view-people space-y-6 animate-fade-in">
      {/* Description header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-slate-300 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-500 to-indigo-500 flex items-center justify-center text-white shadow-md shrink-0">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Personer & Ansikten</h3>
            <p className="text-slate-400">
              Grupperar automatiskt personattribut och ansikten identifierade av Gemini (t.ex. skägg, solglasögon, kompisar).
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 text-[11px] text-slate-300">
          <Sparkles className="w-3 h-3 text-amber-400" />
          <span>{clusters.length} personer identifierade</span>
        </div>
      </div>

      {/* Person Grid */}
      {clusters.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-6">
          {clusters.map((cluster) => {
            const isEditing = editingPersonId === cluster.id;
            return (
              <div
                key={cluster.id}
                role="button"
                tabIndex={0}
                onClick={() => setSelectedCluster(cluster)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') setSelectedCluster(cluster);
                }}
                className="group flex flex-col items-center p-3 sm:p-4 rounded-2xl bg-slate-900/70 hover:bg-slate-800/90 border border-slate-800 hover:border-slate-700 transition cursor-pointer text-center relative shadow-md"
              >
                {/* Circular Profile Avatar */}
                <div className="relative w-20 h-20 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-full p-1 bg-gradient-to-b from-slate-700 via-slate-800 to-slate-900 shadow-xl group-hover:scale-105 transition-transform duration-300">
                  <div className="w-full h-full rounded-full overflow-hidden border-2 border-slate-600/80 group-hover:border-rose-500 transition-colors">
                    <img
                      src={cluster.avatarUrl}
                      alt={cluster.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {/* Photo count badge */}
                  <div className="absolute bottom-0 right-0 px-2 py-0.5 rounded-full bg-slate-900/90 border border-slate-700 text-[10px] font-bold text-slate-200">
                    {cluster.images.length}
                  </div>
                </div>

                {/* Name & Edit */}
                <div className="mt-2.5 w-full" onClick={(e) => isEditing && e.stopPropagation()}>
                  {isEditing ? (
                    <div className="flex items-center justify-center gap-1">
                      <input
                        type="text"
                        value={editInput}
                        onChange={(e) => setEditInput(e.target.value)}
                        autoFocus
                        className="w-20 sm:w-24 px-1.5 py-0.5 text-xs bg-slate-950 border border-rose-500 rounded text-white text-center outline-none"
                      />
                      <button
                        type="button"
                        onClick={(e) => handleSaveEdit(cluster.id, e)}
                        className="p-1 rounded bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/40"
                      >
                        <Check className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelEdit}
                        className="p-1 rounded bg-slate-800 text-slate-400 hover:bg-slate-700"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-1 group/btn">
                      <span className="font-semibold text-xs sm:text-sm text-slate-100 group-hover:text-rose-400 transition-colors truncate max-w-[110px]">
                        {cluster.name}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => handleStartEdit(cluster, e)}
                        title="Namnge person"
                        className="opacity-0 group-hover/btn:opacity-100 p-1 rounded hover:bg-slate-700 text-slate-400 hover:text-white transition"
                      >
                        <Edit3 className="w-2.5 h-2.5" />
                      </button>
                    </div>
                  )}
                  <span className="text-[11px] text-slate-500 block mt-0.5 truncate">
                    {cluster.attribute}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="py-12 text-center rounded-2xl bg-slate-900/40 border border-slate-800 max-w-md mx-auto p-6 space-y-3">
          <User className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-sm font-semibold text-white">Inga personer identifierade ännu</h3>
          <p className="text-xs text-slate-400">
            Ladda upp bilder på personer eller porträtt så grupperas de automatiskt här.
          </p>
        </div>
      )}
    </section>
  );
};

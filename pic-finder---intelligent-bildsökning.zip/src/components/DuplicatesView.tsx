import React, { useState, useMemo } from 'react';
import { Copy, Trash2, CheckCircle2, AlertTriangle, Sparkles, Plus, Image as ImageIcon } from 'lucide-react';
import { IndexedMedia, DuplicatePair } from '../types.js';
import { findDuplicates } from '../utils/duplicateDetector.js';

interface DuplicatesViewProps {
  items: IndexedMedia[];
  onDeleteMedia: (id: string) => void;
  onCreateTestDuplicate: () => void;
}

export const DuplicatesView: React.FC<DuplicatesViewProps> = ({
  items,
  onDeleteMedia,
  onCreateTestDuplicate,
}) => {
  const [similarityThreshold, setSimilarityThreshold] = useState<number>(0.70);

  // Compute duplicate pairs
  const duplicatePairs = useMemo(() => {
    return findDuplicates(items, similarityThreshold);
  }, [items, similarityThreshold]);

  return (
    <section className="view view-duplicates space-y-6 animate-fade-in">
      {/* Header Info Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-slate-300 text-xs">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-md">
            <Copy className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm">Hitta Dubbletter & Lika Foton</h3>
            <p className="text-slate-400">
              Lokal JavaScript-algoritm som jämför visuell information, bildstorlek och AI-taggar.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCreateTestDuplicate}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer text-xs font-semibold"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Skapa testdubblett</span>
          </button>
        </div>
      </div>

      {/* Duplicate Pairs List */}
      {duplicatePairs.length > 0 ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>Hittade <strong>{duplicatePairs.length}</strong> dubblettpar</span>
            <span>Sorterade efter högst likhet</span>
          </div>

          <div className="space-y-4">
            {duplicatePairs.map((pair) => (
              <div
                key={pair.id}
                className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl space-y-4"
              >
                {/* Match indicator header */}
                <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                      {pair.similarity}% likhet
                    </span>
                    <span className="text-xs text-slate-300 font-medium">
                      {pair.reason}
                    </span>
                  </div>
                </div>

                {/* Side-by-side media comparison */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Item A */}
                  <div className="flex flex-col justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                    <div className="aspect-video w-full rounded-lg overflow-hidden bg-black relative">
                      {pair.imageA.mediaType === 'video' ? (
                        <video
                          src={pair.imageA.url}
                          className="w-full h-full object-cover"
                          muted
                          loop
                          playsInline
                        />
                      ) : (
                        <img
                          src={pair.imageA.url}
                          alt={pair.imageA.title}
                          className="w-full h-full object-cover"
                        />
                      )}
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/60 text-[10px] text-white font-semibold">
                        Version A
                      </span>
                    </div>

                    <div className="space-y-1">
                      <h4 className="font-semibold text-xs text-white truncate">{pair.imageA.title}</h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{pair.imageA.tags.slice(0, 5).join(', ')}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteMedia(pair.imageA.id)}
                      className="flex items-center justify-center gap-1.5 w-full py-2 rounded-lg bg-rose-500/15 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-semibold transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Radera Version A</span>
                    </button>
                  </div>

                  {/* Item B */}
                  <div className="flex flex-col justify-between p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-3">
                    <div className="aspect-video w-full rounded-lg overflow-hidden bg-black relative">
                      {pair.imageB.mediaType === 'video' ? (
                        <video
                          src={pair.imageB.url}
                          className="w-full h-full object-cover"
                          muted
                          loop
                          playsInline
                        />
                      ) : (
                        <img
                          src={pair.imageB.url}
                          alt={pair.imageB.title}
                          className="w-full h-full object-cover"
                        />
                      )}
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/60 text-[10px] text-white font-semibold">
                        Version B
                      </span>
                    </div>

                    <div className="space-y-1">
                      <h4 className="font-semibold text-xs text-white truncate">{pair.imageB.title}</h4>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{pair.imageB.tags.slice(0, 5).join(', ')}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteMedia(pair.imageB.id)}
                      className="flex items-center justify-center gap-1.5 w-full py-2 rounded-lg bg-rose-500/15 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-semibold transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Radera Version B</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Empty duplicates state */
        <div className="py-16 text-center rounded-2xl bg-slate-900/40 border border-slate-800 max-w-md mx-auto p-6 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto text-emerald-400">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold text-white">Inga dubbletter hittades!</h3>
            <p className="text-xs text-slate-400">
              Ditt mediebibliotek är rent och organiserat. Alla sparade bilder och videor är unika.
            </p>
          </div>
          <button
            type="button"
            onClick={onCreateTestDuplicate}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>Skapa testdubblett för att prova</span>
          </button>
        </div>
      )}
    </section>
  );
};

import React, { useRef, useEffect } from 'react';
import { Search, X, Sparkles, CornerDownLeft } from 'lucide-react';

interface SearchBarProps {
  query: string;
  setQuery: (q: string) => void;
  resultCount: number;
  totalCount: number;
  onClear: () => void;
}

const SAMPLE_QUERIES = [
  'när jag stod framför en röd Ferrari',
  'kompisar på en restaurang',
  'solnedgång vid strand utomlands',
  'hund som leker på gräsmatta',
  'kaffekopp och laptop vid fönster',
  'mysig stuga i vinterberg',
  'bad och pool på lyxhotell',
  'spelar fotboll på fotbollsplan',
];

export const SearchBar: React.FC<SearchBarProps> = ({
  query,
  setQuery,
  resultCount,
  totalCount,
  onClear,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut '/' to focus search input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement !== inputRef.current) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-3">
      {/* Search Input Box */}
      <div className="relative group">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <Search className="w-5 h-5 text-slate-400 group-focus-within:text-rose-400 transition-colors" />
        </div>

        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Beskriv vad du letar efter (t.ex. 'när jag stod framför en röd Ferrari' eller 'kompisar på en restaurang')..."
          aria-label="Sök i dina foton med naturligt språk"
          className="w-full pl-12 pr-28 py-4 bg-slate-800/90 hover:bg-slate-800 focus:bg-slate-800 border-2 border-slate-700/80 focus:border-rose-500/80 rounded-2xl text-slate-100 placeholder:text-slate-400 text-sm sm:text-base outline-none shadow-xl shadow-slate-950/30 transition duration-200"
        />

        <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-2">
          {query ? (
            <button
              type="button"
              onClick={onClear}
              aria-label="Rensa sökning"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <kbd className="hidden sm:inline-flex items-center px-2 py-0.5 text-[11px] font-mono font-medium text-slate-400 bg-slate-700/60 border border-slate-600 rounded">
              /
            </kbd>
          )}

          <div className="h-6 w-px bg-slate-700" />
          <div className="flex items-center text-xs font-medium text-slate-400 pr-1">
            <span className="text-white font-bold mr-1">{resultCount}</span> / {totalCount}
          </div>
        </div>
      </div>

      {/* Suggested Natural Language Queries from user instructions */}
      <div className="flex flex-wrap items-center gap-1.5 text-xs">
        <span className="inline-flex items-center gap-1 text-slate-400 font-medium mr-1 py-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          Testa naturliga sökningar:
        </span>
        {SAMPLE_QUERIES.map((q) => {
          const isActive = query.toLowerCase() === q.toLowerCase();
          return (
            <button
              key={q}
              type="button"
              onClick={() => setQuery(q)}
              className={`px-2.5 py-1 rounded-full border transition cursor-pointer text-left ${
                isActive
                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-sm font-semibold'
                  : 'bg-slate-800/60 text-slate-300 border-slate-700/60 hover:bg-slate-700 hover:text-white hover:border-slate-600'
              }`}
            >
              "{q}"
            </button>
          );
        })}
      </div>
    </div>
  );
};

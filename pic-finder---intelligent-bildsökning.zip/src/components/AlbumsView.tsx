import React from 'react';
import { Film, User, Monitor, Heart, Clock, Folder, ChevronRight, Layers } from 'lucide-react';
import { IndexedMedia, MediaType } from '../types.js';

interface AlbumsViewProps {
  items: IndexedMedia[];
  onSelectMediaType: (type: MediaType | 'all') => void;
  onOpenLibrary: () => void;
  onOpenPeople: () => void;
  onOpenDuplicates: () => void;
}

export const AlbumsView: React.FC<AlbumsViewProps> = ({
  items,
  onSelectMediaType,
  onOpenLibrary,
  onOpenPeople,
  onOpenDuplicates,
}) => {
  const videoItems = items.filter((i) => i.mediaType === 'video');
  const portraitItems = items.filter((i) => i.mediaType === 'portrait');
  const screenshotItems = items.filter((i) => i.mediaType === 'screenshot');
  const photoItems = items.filter((i) => i.mediaType === 'photo');

  const albums = [
    {
      id: 'recents',
      title: 'Alla medier',
      count: items.length,
      icon: Clock,
      coverUrl: items[0]?.url,
      isVideo: items[0]?.mediaType === 'video',
      onClick: () => {
        onSelectMediaType('all');
        onOpenLibrary();
      },
    },
    {
      id: 'videos',
      title: 'Videor',
      count: videoItems.length,
      icon: Film,
      coverUrl: videoItems[0]?.url,
      isVideo: true,
      onClick: () => {
        onSelectMediaType('video');
        onOpenLibrary();
      },
    },
    {
      id: 'portraits',
      title: 'Porträtt',
      count: portraitItems.length,
      icon: User,
      coverUrl: portraitItems[0]?.url,
      isVideo: false,
      onClick: () => {
        onSelectMediaType('portrait');
        onOpenLibrary();
      },
    },
    {
      id: 'screenshots',
      title: 'Skärmbilder',
      count: screenshotItems.length,
      icon: Monitor,
      coverUrl: screenshotItems[0]?.url,
      isVideo: false,
      onClick: () => {
        onSelectMediaType('screenshot');
        onOpenLibrary();
      },
    },
    {
      id: 'photos',
      title: 'Bilder & Foton',
      count: photoItems.length,
      icon: Layers,
      coverUrl: photoItems[0]?.url,
      isVideo: false,
      onClick: () => {
        onSelectMediaType('photo');
        onOpenLibrary();
      },
    },
    {
      id: 'people_shortcut',
      title: 'Personer & Ansikten',
      count: items.filter((i) => i.categories.people.length > 0).length,
      icon: User,
      coverUrl: portraitItems[0]?.url || items[1]?.url,
      isVideo: false,
      onClick: onOpenPeople,
    },
  ];

  return (
    <section className="view view-albums space-y-6 animate-fade-in">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Folder className="w-5 h-5 text-rose-400" />
            Mina Album
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Automatiskt sorterade efter mediatyp, händelser och innehåll.
          </p>
        </div>
      </div>

      {/* Album Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
        {albums.map((album) => {
          const Icon = album.icon;
          return (
            <button
              key={album.id}
              type="button"
              onClick={album.onClick}
              className="group flex flex-col text-left p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer shadow-lg hover:shadow-2xl hover:shadow-black/60 focus:outline-none focus:ring-2 focus:ring-rose-500"
            >
              {/* Album Cover */}
              <div className="aspect-square w-full rounded-xl overflow-hidden bg-slate-950 relative mb-3">
                {album.coverUrl ? (
                  album.isVideo ? (
                    <video
                      src={album.coverUrl}
                      muted
                      loop
                      playsInline
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <img
                      src={album.coverUrl}
                      alt={album.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  )
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-700">
                    <Icon className="w-10 h-10" />
                  </div>
                )}
                {/* Count Pill */}
                <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-md text-[11px] font-mono font-bold text-white border border-white/10">
                  {album.count}
                </div>
              </div>

              {/* Title & Subtitle */}
              <div className="flex items-center justify-between w-full">
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-white group-hover:text-rose-400 transition-colors">
                    {album.title}
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    {album.count} {album.count === 1 ? 'objekt' : 'objekt'}
                  </span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 group-hover:translate-x-0.5 transition" />
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
};

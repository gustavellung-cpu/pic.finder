import React from 'react';
import { Camera, Sparkles, Upload, Terminal, Image as ImageIcon, Users, Copy, Film } from 'lucide-react';

export type AppViewTab = 'library' | 'people' | 'duplicates';

interface HeaderProps {
  currentTab: AppViewTab;
  onSelectTab: (tab: AppViewTab) => void;
  totalImages: number;
  totalTags: number;
  duplicateCount: number;
  onOpenUpload: () => void;
  onOpenPrompt: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  totalImages,
  totalTags,
  duplicateCount,
  onOpenUpload,
  onOpenPrompt,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-rose-500/20">
            <ImageIcon className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                Pic Finder
              </h1>
              <span className="text-[11px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                Semantisk AI
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Intelligent sökning & album för bilder & videor
            </p>
          </div>
        </div>

        {/* Center Nav Tabs */}
        <nav className="flex items-center p-1 bg-slate-950/80 rounded-xl border border-slate-800 text-xs font-semibold">
          <button
            type="button"
            onClick={() => onSelectTab('library')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
              currentTab === 'library'
                ? 'bg-rose-500 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Bibliotek</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('people')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer ${
              currentTab === 'people'
                ? 'bg-rose-500 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Personer</span>
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('duplicates')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition cursor-pointer relative ${
              currentTab === 'duplicates'
                ? 'bg-rose-500 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Dubbletter</span>
            {duplicateCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-amber-400 absolute top-1 right-1" />
            )}
          </button>
        </nav>

        {/* Stats & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* AI Prompt Inspector Button */}
          <button
            type="button"
            onClick={onOpenPrompt}
            aria-label="Visa AI-prompt och systeminstruktioner"
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer"
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>AI-Prompt</span>
          </button>

          {/* Upload / Index Button */}
          <button
            type="button"
            onClick={onOpenUpload}
            aria-label="Ladda upp bilder eller videor"
            className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-xs sm:text-sm font-semibold bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white shadow-md shadow-rose-500/20 transition cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <span className="hidden xs:inline">Ladda upp</span>
          </button>
        </div>
      </div>
    </header>
  );
};

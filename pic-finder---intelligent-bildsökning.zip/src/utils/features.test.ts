import test from 'node:test';
import assert from 'node:assert/strict';
import { computeTagSimilarity, findDuplicates } from './duplicateDetector.js';
import { groupImagesByPerson } from './personGrouper.js';
import { IndexedMedia } from '../types.js';

test('computeTagSimilarity calculates Jaccard index accurately', () => {
  const tagsA = ['röd ferrari', 'sportbil', 'bil', 'soligt'];
  const tagsB = ['röd ferrari', 'sportbil', 'bil', 'strand'];
  const sim = computeTagSimilarity(tagsA, tagsB);
  // 3 intersection / 5 union = 0.6
  assert.equal(Math.round(sim * 100), 60);
});

test('findDuplicates finds identical or high-similarity pairs', () => {
  const mockItems: IndexedMedia[] = [
    {
      id: 'img1',
      title: 'Ferrari original',
      url: 'https://example.com/ferrari.jpg',
      mediaType: 'photo',
      tags: ['röd ferrari', 'sportbil', 'superbil', 'bil', 'gata', 'sommar'],
      rawTagsString: 'röd ferrari, sportbil, superbil, bil, gata, sommar',
      categories: { objects: ['bil'], environment: ['gata'], people: [], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample',
    },
    {
      id: 'img2',
      title: 'Ferrari kopia',
      url: 'https://example.com/ferrari-copy.jpg',
      mediaType: 'photo',
      tags: ['röd ferrari', 'sportbil', 'superbil', 'bil', 'gata', 'sommar'],
      rawTagsString: 'röd ferrari, sportbil, superbil, bil, gata, sommar',
      categories: { objects: ['bil'], environment: ['gata'], people: [], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'upload',
    },
    {
      id: 'img3',
      title: 'Hund i park',
      url: 'https://example.com/dog.jpg',
      mediaType: 'photo',
      tags: ['hund', 'gräsmatta', 'park', 'leker'],
      rawTagsString: 'hund, gräsmatta, park, leker',
      categories: { objects: [], environment: ['park'], people: [], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample',
    },
  ];

  const duplicates = findDuplicates(mockItems, 0.70);
  assert.equal(duplicates.length, 1);
  assert.equal(duplicates[0].imageA.id, 'img1');
  assert.equal(duplicates[0].imageB.id, 'img2');
  assert.ok(duplicates[0].similarity >= 95);
});

test('groupImagesByPerson clusters friends and people correctly', () => {
  const mockItems: IndexedMedia[] = [
    {
      id: 'friends1',
      title: 'Vänner middag',
      url: 'https://example.com/friends1.jpg',
      mediaType: 'photo',
      tags: ['kompisar', 'vänner', 'middag', 'restaurang'],
      rawTagsString: 'kompisar, vänner, middag, restaurang',
      categories: { objects: [], environment: [], people: ['kompisar', 'vänner'], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample',
    },
    {
      id: 'friends2',
      title: 'Vänner strand',
      url: 'https://example.com/friends2.jpg',
      mediaType: 'photo',
      tags: ['kompisar', 'strand', 'badar'],
      rawTagsString: 'kompisar, strand, badar',
      categories: { objects: [], environment: [], people: ['kompisar'], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample',
    },
  ];

  const clusters = groupImagesByPerson(mockItems);
  assert.ok(clusters.length > 0);
  assert.equal(clusters[0].id, 'kompisar');
  assert.equal(clusters[0].images.length, 2);
});

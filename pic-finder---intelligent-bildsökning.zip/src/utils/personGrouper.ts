import { IndexedMedia, PersonCluster } from '../types.js';

// Predefined or dynamically extracted person clusters
const PERSON_PATTERNS = [
  { id: 'kompisar', label: 'Vänner & Kompisar', keywords: ['kompisar', 'vänner', 'sällskap', 'umgänge', 'grupp'] },
  { id: 'kvinna-kafe', label: 'Kvinna vid fönster', keywords: ['kvinna', 'sitter vid fönster', 'dricker kaffe', 'fikar'] },
  { id: 'fotbollsspelare', label: 'Fotboll & Idrottare', keywords: ['fotbollsspelare', 'spelar fotboll', 'sportkläder', 'lag'] },
  { id: 'bilforare', label: 'Förare & Bilar', keywords: ['står framför bil', 'förare', 'personer vid bil'] },
  { id: 'strand-badare', label: 'Badare & Solsemester', keywords: ['badar', 'simmar', 'solstolar', 'strandliv'] },
  { id: 'skidresenar', label: 'Vinterresenär', keywords: ['skidresa', 'friluftsliv', 'vinterkläder'] },
];

export function groupImagesByPerson(items: IndexedMedia[]): PersonCluster[] {
  const clusters: Map<string, PersonCluster> = new Map();

  for (const item of items) {
    const peopleTags = [
      ...item.categories.people,
      ...(item.personAttributes || []),
      ...item.tags.filter(t => 
        t.includes('person') || t.includes('kompis') || t.includes('man') || 
        t.includes('kvinna') || t.includes('barn') || t.includes('tjej') || 
        t.includes('kille') || t.includes('står framför') || t.includes('sitter vid') ||
        t.includes('dricker') || t.includes('äter') || t.includes('spelar')
      )
    ];

    if (!peopleTags.length) continue;

    // Check matching pattern
    let matchedPattern = PERSON_PATTERNS.find(p => 
      p.keywords.some(kw => peopleTags.some(t => t.toLowerCase().includes(kw)))
    );

    // If no pattern matched, but image has person tags, create a cluster from the primary person tag
    const clusterId = matchedPattern ? matchedPattern.id : `person-${peopleTags[0].toLowerCase().replace(/\s+/g, '-')}`;
    const clusterName = matchedPattern ? matchedPattern.label : (peopleTags[0].charAt(0).toUpperCase() + peopleTags[0].slice(1));
    const attribute = matchedPattern ? matchedPattern.keywords[0] : peopleTags[0];

    if (!clusters.has(clusterId)) {
      clusters.set(clusterId, {
        id: clusterId,
        name: clusterName,
        attribute,
        avatarUrl: item.thumbnailUrl || item.url,
        images: [item],
      });
    } else {
      const existing = clusters.get(clusterId)!;
      if (!existing.images.some(img => img.id === item.id)) {
        existing.images.push(item);
      }
    }
  }

  // Return clusters with at least 1 image, sorted by most images
  return Array.from(clusters.values()).sort((a, b) => b.images.length - a.images.length);
}

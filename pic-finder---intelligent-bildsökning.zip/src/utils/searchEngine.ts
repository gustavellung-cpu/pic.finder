import { IndexedImage, SearchResult } from '../types.js';

// Common Swedish and English stopwords that shouldn't dominate search scoring
export const STOPWORDS = new Set([
  // Swedish stopwords
  'när', 'jag', 'vi', 'du', 'han', 'hon', 'de', 'den', 'det', 'en', 'ett',
  'på', 'i', 'vid', 'framför', 'bakom', 'med', 'utan', 'och', 'eller', 'som',
  'är', 'var', 'hade', 'har', 'ska', 'skulle', 'stod', 'satt', 'gick', 'såg',
  'någon', 'något', 'några', 'mitt', 'min', 'mina', 'din', 'ditt', 'dina',
  'där', 'här', 'till', 'från', 'av', 'om', 'under', 'över', 'efter',
  // English common words
  'when', 'i', 'we', 'you', 'he', 'she', 'they', 'a', 'an', 'the', 'in', 'on',
  'at', 'in front of', 'with', 'and', 'or', 'that', 'was', 'were', 'is', 'standing',
]);

// Helper to normalize strings for comparison
export function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // remove diacritics for flexible search
    .replace(/[^\w\s\såäöÅÄÖ]/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

// Clean and parse comma-separated tags from Gemini response
export function parseRawTags(rawText: string): string[] {
  if (!rawText) return [];
  
  // Split on commas, clean quotes and extra bullets/numbers if any
  const parts = rawText
    .split(/[,;\n]+/)
    .map(p => p.replace(/^[\s\d\-•*."'`]+|[\s."'`]+$/g, '').trim())
    .filter(p => p.length > 1);

  // Deduplicate case-insensitively while preserving original casing
  const seen = new Set<string>();
  const uniqueTags: string[] = [];

  for (const tag of parts) {
    const key = tag.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      uniqueTags.push(tag);
    }
  }

  return uniqueTags;
}

// Heuristic categorization for the 5 requested categories
export function categorizeTags(tags: string[]): IndexedImage['categories'] {
  const result: IndexedImage['categories'] = {
    objects: [],
    environment: [],
    people: [],
    colors: [],
    context: [],
    other: [],
  };

  const objectKeywords = [
    'bil', 'ferrari', 'fordon', 'hund', 'katt', 'cykel', 'båt', 'vägg', 'pool', 'kaffe',
    'kopp', 'bord', 'stol', 'tallrik', 'glas', 'mobil', 'dator', 'kläder', 'jacka', 'tröja',
    'boll', 'träd', 'blomma', 'väska', 'glasögon', 'klocka', 'motorcykel', 'flygplan', 'mat',
    'pizza', 'pasta', 'öl', 'vin', 'telefon', 'skor', 'kamera', 'buss', 'tåg', 'skärm', 'bok'
  ];

  const envKeywords = [
    'strand', 'restaurang', 'utomhus', 'inomhus', 'fotbollsplan', 'gräsmatta', 'berg', 'stad',
    'hav', 'sjö', 'skog', 'park', 'café', 'kafé', 'kök', 'rum', 'kontor', 'gata', 'torg',
    'natur', 'hotell', 'balkong', 'trädgård', 'väg', 'spanien', 'italien', 'sverige', 'alperna',
    'medelhavet', 'landskap', 'vatten', 'himmel', 'naturreservat', 'kust', 'skidbacke'
  ];

  const peopleKeywords = [
    'kompisar', 'kompis', 'vänner', 'vän', 'personer', 'person', 'kille', 'tjej', 'man', 'kvinna',
    'barn', 'pojke', 'flicka', 'spelar', 'sitter', 'står', 'går', 'springer', 'äter', 'dricker',
    'pratar', 'skrattar', 'leende', 'promenad', 'poserar', 'tittar', 'dansar', 'badar', 'jobbar',
    'simmar', 'lagar', 'fotograferar', 'fikar', 'sällskap', 'grupp'
  ];

  const colorTimeKeywords = [
    'solnedgång', 'soluppgång', 'ljust', 'mörkt', 'blå', 'röd', 'grön', 'gul', 'vit', 'svart',
    'orange', 'lila', 'rosa', 'grå', 'brun', 'kväll', 'natt', 'morgon', 'dag', 'eftermiddag',
    'soligt', 'molnigt', 'dimma', 'skymning', 'gyllene timmen', 'skugga', 'kontrast', 'varmt ljus',
    'kallt ljus', 'neon', 'sken'
  ];

  const contextKeywords = [
    'semester', 'fest', 'sport', 'vardag', 'sommar', 'vinter', 'höst', 'vår', 'avkoppling',
    'mysigt', 'glädje', 'äventyr', 'resa', 'firande', 'romantiskt', 'professionell', 'arbete',
    'lugn', 'energi', 'aktivitet', 'fritid', 'semesterkänsla', 'weekend', 'födelsedag'
  ];

  for (const tag of tags) {
    const lower = tag.toLowerCase();
    let assigned = false;

    if (objectKeywords.some(kw => lower.includes(kw))) {
      result.objects.push(tag);
      assigned = true;
    }
    if (envKeywords.some(kw => lower.includes(kw))) {
      result.environment.push(tag);
      assigned = true;
    }
    if (peopleKeywords.some(kw => lower.includes(kw))) {
      result.people.push(tag);
      assigned = true;
    }
    if (colorTimeKeywords.some(kw => lower.includes(kw))) {
      result.colors.push(tag);
      assigned = true;
    }
    if (contextKeywords.some(kw => lower.includes(kw))) {
      result.context.push(tag);
      assigned = true;
    }

    if (!assigned) {
      result.other.push(tag);
    }
  }

  return result;
}

// Extract keywords and significant n-grams from a natural language query
export function extractQueryTokens(query: string): { keywords: string[]; phrases: string[] } {
  const normQuery = query.toLowerCase().trim();
  const rawWords = normQuery.split(/\s+/).map(w => w.replace(/[^\wåäöÅÄÖ]/g, '')).filter(Boolean);

  // Extract non-stop words
  const keywords = rawWords.filter(w => !STOPWORDS.has(w) && w.length >= 2);

  // Generate 2-word and 3-word n-gram phrases (e.g. "röd ferrari", "äter på restaurang")
  const phrases: string[] = [];
  for (let i = 0; i < rawWords.length - 1; i++) {
    const bigram = `${rawWords[i]} ${rawWords[i + 1]}`;
    phrases.push(bigram);
    if (i < rawWords.length - 2) {
      const trigram = `${rawWords[i]} ${rawWords[i + 1]} ${rawWords[i + 2]}`;
      phrases.push(trigram);
    }
  }

  return { keywords, phrases };
}

// Compute semantic search matches and ranking
export function searchImages(query: string, images: IndexedImage[]): SearchResult[] {
  const trimmed = query.trim();
  if (!trimmed) {
    // If empty query, return all images with score 100
    return images.map(img => ({
      image: img,
      score: 100,
      matchedTags: [],
      matchReasons: [],
    }));
  }

  const { keywords, phrases } = extractQueryTokens(trimmed);
  const normalizedQuery = normalize(trimmed);

  const results: SearchResult[] = [];

  for (const img of images) {
    let score = 0;
    const matchedTagsSet = new Set<string>();
    const matchReasons: string[] = [];

    const normTags = img.tags.map(t => ({
      original: t,
      normalized: normalize(t),
    }));

    // Check full query match against any tag or title
    for (const tag of normTags) {
      if (tag.normalized === normalizedQuery) {
        score += 60;
        matchedTagsSet.add(tag.original);
        matchReasons.push(`Exakt matchning: "${tag.original}"`);
      } else if (tag.normalized.includes(normalizedQuery) || normalizedQuery.includes(tag.normalized)) {
        score += 40;
        matchedTagsSet.add(tag.original);
      }
    }

    // Check n-gram phrases (e.g. "röd ferrari", "kompisar på restaurang")
    for (const phrase of phrases) {
      const normPhrase = normalize(phrase);
      for (const tag of normTags) {
        if (tag.normalized.includes(normPhrase) || normPhrase.includes(tag.normalized)) {
          score += 35;
          matchedTagsSet.add(tag.original);
          if (!matchReasons.includes(`Fras: "${tag.original}"`)) {
            matchReasons.push(`Fras: "${tag.original}"`);
          }
        }
      }
    }

    // Check individual keywords & partial stems
    let matchedKeywordCount = 0;
    for (const kw of keywords) {
      const normKw = normalize(kw);
      let kwMatched = false;

      for (const tag of normTags) {
        // Exact word boundary or prefix
        if (tag.normalized === normKw) {
          score += 25;
          matchedTagsSet.add(tag.original);
          kwMatched = true;
        } else if (tag.normalized.includes(normKw)) {
          score += 15;
          matchedTagsSet.add(tag.original);
          kwMatched = true;
        } else if (normKw.length >= 4 && tag.normalized.startsWith(normKw.slice(0, 4))) {
          // stem match (e.g. kompis -> kompisar)
          score += 12;
          matchedTagsSet.add(tag.original);
          kwMatched = true;
        }
      }

      if (kwMatched) {
        matchedKeywordCount++;
      }
    }

    // Bonus if all query keywords matched
    if (keywords.length > 1 && matchedKeywordCount === keywords.length) {
      score += 25;
      matchReasons.push('Alla sökord identifierades i bilden');
    } else if (matchedKeywordCount > 1) {
      score += matchedKeywordCount * 5;
    }

    // Cap score at 100
    const finalScore = Math.min(100, Math.round(score));

    if (finalScore > 0 || matchedTagsSet.size > 0) {
      results.push({
        image: img,
        score: Math.max(15, finalScore),
        matchedTags: Array.from(matchedTagsSet),
        matchReasons: matchReasons.slice(0, 3),
      });
    }
  }

  // Sort descending by score
  return results.sort((a, b) => b.score - a.score);
}

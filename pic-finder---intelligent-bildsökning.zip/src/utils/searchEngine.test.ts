import test from 'node:test';
import assert from 'node:assert/strict';
import { parseRawTags, searchImages, extractQueryTokens, categorizeTags } from './searchEngine.js';
import { IndexedImage } from '../types.js';

test('parseRawTags correctly parses comma-separated lists and deduplicates', () => {
  const raw = 'röd ferrari, sportbil, bil, solnedgång, strand, Röd Ferrari, utomlands, kompisar';
  const tags = parseRawTags(raw);
  assert.equal(tags.length, 7);
  assert.ok(tags.includes('röd ferrari'));
  assert.ok(tags.includes('sportbil'));
  assert.ok(tags.includes('kompisar'));
});

test('extractQueryTokens separates stopwords and generates n-grams', () => {
  const { keywords, phrases } = extractQueryTokens('när jag stod framför en röd Ferrari');
  assert.ok(keywords.includes('röd'));
  assert.ok(keywords.includes('ferrari'));
  assert.ok(!keywords.includes('jag'));
  assert.ok(!keywords.includes('när'));
  assert.ok(phrases.some(p => p.includes('röd ferrari')));
});

test('searchImages ranks Ferrari image highest for "när jag stod framför en röd Ferrari"', () => {
  const mockImages: IndexedImage[] = [
    {
      id: '1',
      title: 'Röd sportbil',
      url: 'https://images.unsplash.com/photo-1',
      rawTagsString: 'röd ferrari, sportbil, bil, utomhus, asfalt, står framför bil, röd färg, soligt',
      tags: ['röd ferrari', 'sportbil', 'bil', 'utomhus', 'asfalt', 'står framför bil', 'röd färg', 'soligt'],
      categories: { objects: ['röd ferrari', 'sportbil', 'bil'], environment: ['utomhus'], people: ['står framför bil'], colors: ['röd färg', 'soligt'], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample'
    },
    {
      id: '2',
      title: 'Middag med vänner',
      url: 'https://images.unsplash.com/photo-2',
      rawTagsString: 'kompisar, restaurang, äter middag, mat, bord, vin, glädje, kväll, inomhus',
      tags: ['kompisar', 'restaurang', 'äter middag', 'mat', 'bord', 'vin', 'glädje', 'kväll', 'inomhus'],
      categories: { objects: ['bord', 'mat'], environment: ['restaurang', 'inomhus'], people: ['kompisar', 'äter middag'], colors: ['kväll'], context: ['glädje'], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample'
    }
  ];

  const results = searchImages('när jag stod framför en röd Ferrari', mockImages);
  assert.ok(results.length > 0);
  assert.equal(results[0].image.id, '1');
  assert.ok(results[0].score > 50);
  assert.ok(results[0].matchedTags.includes('röd ferrari'));
});

test('searchImages matches "kompisar på en restaurang" correctly', () => {
  const mockImages: IndexedImage[] = [
    {
      id: 'ferrari',
      title: 'Ferrari',
      url: 'https://images.unsplash.com/ferrari',
      rawTagsString: 'ferrari, röd bil',
      tags: ['ferrari', 'röd bil'],
      categories: { objects: ['ferrari', 'röd bil'], environment: [], people: [], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample'
    },
    {
      id: 'dinner',
      title: 'Kompisar på middag',
      url: 'https://images.unsplash.com/dinner',
      rawTagsString: 'kompisar, äter på restaurang, restaurang, vänner, middag, vin',
      tags: ['kompisar', 'äter på restaurang', 'restaurang', 'vänner', 'middag', 'vin'],
      categories: { objects: [], environment: ['restaurang'], people: ['kompisar', 'vänner', 'äter på restaurang'], colors: [], context: [], other: [] },
      indexedAt: new Date().toISOString(),
      source: 'sample'
    }
  ];

  const results = searchImages('kompisar på en restaurang', mockImages);
  assert.ok(results.length > 0);
  assert.equal(results[0].image.id, 'dinner');
  assert.ok(results[0].matchedTags.includes('kompisar'));
  assert.ok(results[0].matchedTags.includes('restaurang'));
});

test('categorizeTags correctly categorizes Swedish tags', () => {
  const tags = ['röd ferrari', 'strand', 'kompisar', 'solnedgång', 'semester'];
  const categorized = categorizeTags(tags);
  assert.ok(categorized.objects.includes('röd ferrari'));
  assert.ok(categorized.environment.includes('strand'));
  assert.ok(categorized.people.includes('kompisar'));
  assert.ok(categorized.colors.includes('solnedgång'));
  assert.ok(categorized.context.includes('semester'));
});

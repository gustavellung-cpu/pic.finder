import { IndexedMedia, DuplicatePair } from '../types.js';

// Calculate Jaccard similarity between two tag sets (0.0 to 1.0)
export function computeTagSimilarity(tagsA: string[], tagsB: string[]): number {
  if (!tagsA.length || !tagsB.length) return 0;
  
  const setA = new Set(tagsA.map(t => t.toLowerCase().trim()));
  const setB = new Set(tagsB.map(t => t.toLowerCase().trim()));

  let intersectionCount = 0;
  for (const t of setA) {
    if (setB.has(t)) {
      intersectionCount++;
    }
  }

  const unionSize = new Set([...setA, ...setB]).size;
  if (unionSize === 0) return 0;

  return intersectionCount / unionSize;
}

// Find duplicate pairs in a list of images/videos
export function findDuplicates(items: IndexedMedia[], threshold = 0.70): DuplicatePair[] {
  const pairs: DuplicatePair[] = [];
  const n = items.length;

  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const itemA = items[i];
      const itemB = items[j];

      // Exact URL match
      if (itemA.url && itemB.url && itemA.url === itemB.url) {
        pairs.push({
          id: `dup-${itemA.id}-${itemB.id}`,
          imageA: itemA,
          imageB: itemB,
          similarity: 100,
          reason: 'Exakt samma bildfil (100% identisk URL)',
        });
        continue;
      }

      // Visual hash match if present
      if (itemA.visualHash && itemB.visualHash && itemA.visualHash === itemB.visualHash) {
        pairs.push({
          id: `dup-${itemA.id}-${itemB.id}`,
          imageA: itemA,
          imageB: itemB,
          similarity: 99,
          reason: 'Identiskt visuellt fingeravtryck (dHash)',
        });
        continue;
      }

      // Semantic tag similarity
      const tagSim = computeTagSimilarity(itemA.tags, itemB.tags);
      
      // Bonus if titles or categories overlap closely
      let combinedSim = tagSim;
      if (itemA.mediaType === itemB.mediaType) {
        combinedSim += 0.05;
      }

      if (combinedSim >= threshold) {
        const pct = Math.min(99, Math.round(combinedSim * 100));
        let reason = `Hög semantisk likhet (${pct}%)`;
        if (pct >= 90) {
          reason = `Nästan identiska AI-taggar (${pct}% likhet)`;
        } else if (pct >= 80) {
          reason = `Starkt matchande motiv och attribut (${pct}% likhet)`;
        }

        pairs.push({
          id: `dup-${itemA.id}-${itemB.id}`,
          imageA: itemA,
          imageB: itemB,
          similarity: pct,
          reason,
        });
      }
    }
  }

  // Sort by highest similarity first
  return pairs.sort((a, b) => b.similarity - a.similarity);
}

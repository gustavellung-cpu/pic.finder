import React, { useState, useEffect, useMemo } from 'react';
import { Navigation, NavTab } from './components/Navigation.js';
import { SearchView } from './components/SearchView.js';
import { AlbumsView } from './components/AlbumsView.js';
import { PersonAlbumsView } from './components/PersonAlbumsView.js';
import { DuplicatesView } from './components/DuplicatesView.js';
import { MediaTypeFilter } from './components/MediaTypeFilter.js';
import { CategoryFilter } from './components/CategoryFilter.js';
import { ImageCard } from './components/ImageCard.js';
import { ImageDetailModal } from './components/ImageDetailModal.js';
import { UploadModal } from './components/UploadModal.js';
import { PromptModal } from './components/PromptModal.js';
import { INITIAL_SAMPLE_IMAGES } from './data/sampleImages.js';
import { IndexedMedia, SearchResult, MediaType } from './types.js';
import { searchImages, parseRawTags, categorizeTags } from './utils/searchEngine.js';
import { findDuplicates } from './utils/duplicateDetector.js';
import { Sparkles, ImageOff, RefreshCw, Upload, Terminal, Image as ImageIcon } from 'lucide-react';

const STORAGE_KEY = 'pic_finder_media_v3';

export default function App() {
  // Load media items from localStorage or fallback to defaults
  const [items, setItems] = useState<IndexedMedia[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to load saved items, using defaults');
    }
    return INITIAL_SAMPLE_IMAGES;
  });

  // Save to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.warn('Failed to save items to localStorage', e);
    }
  }, [items]);

  // View & Filter states (5 views: library | search | albums | people | duplicates)
  const [currentTab, setCurrentTab] = useState<NavTab>('library');
  const [selectedMediaType, setSelectedMediaType] = useState<MediaType | 'all'>('all');
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedItem, setSelectedItem] = useState<IndexedMedia | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isPromptOpen, setIsPromptOpen] = useState(false);
  const [isReindexing, setIsReindexing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Show brief toast
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Media type counters
  const mediaCounts = useMemo(() => {
    const counts = {
      all: items.length,
      photo: 0,
      video: 0,
      portrait: 0,
      screenshot: 0,
    };
    items.forEach((item) => {
      if (item.mediaType in counts) {
        counts[item.mediaType]++;
      }
    });
    return counts;
  }, [items]);

  // Duplicate pairs count for badge
  const duplicatePairsCount = useMemo(() => {
    return findDuplicates(items, 0.70).length;
  }, [items]);

  // Filter items by media type first, then category
  const filteredMedia = useMemo(() => {
    let list = items;

    if (selectedMediaType !== 'all') {
      list = list.filter((item) => item.mediaType === selectedMediaType);
    }

    if (selectedCategory !== 'all') {
      list = list.filter((item) => {
        const catList = item.categories[selectedCategory as keyof IndexedMedia['categories']];
        return Array.isArray(catList) && catList.length > 0;
      });
    }

    return list;
  }, [items, selectedMediaType, selectedCategory]);

  // Execute natural language semantic search
  const searchResults: SearchResult[] = useMemo(() => {
    return searchImages(query, filteredMedia);
  }, [query, filteredMedia]);

  // Search results over all items for the dedicated Sök view
  const searchViewResults: SearchResult[] = useMemo(() => {
    return searchImages(query, items);
  }, [query, items]);

  // Total unique semantic tags
  const totalUniqueTags = useMemo(() => {
    const set = new Set<string>();
    items.forEach((item) => item.tags.forEach((t) => set.add(t.toLowerCase())));
    return set.size;
  }, [items]);

  // Re-index media item with Gemini
  const handleReindex = async (itemToReindex: IndexedMedia) => {
    setIsReindexing(true);
    try {
      const res = await fetch('/api/analyze-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageUrl: itemToReindex.url,
          mimeType: itemToReindex.mediaType === 'video' ? 'video/mp4' : 'image/jpeg',
        }),
      });

      if (!res.ok) {
        throw new Error('Kunde inte nå Gemini analysserver.');
      }

      const data = await res.json();
      const rawText = data.rawText || '';
      const tags = parseRawTags(rawText);
      const categories = categorizeTags(tags);
      const detectedType = data.detectedMediaType || itemToReindex.mediaType;

      const updated: IndexedMedia = {
        ...itemToReindex,
        mediaType: detectedType,
        rawTagsString: rawText,
        tags,
        categories,
        indexedAt: new Date().toISOString(),
      };

      setItems((prev) => prev.map((it) => (it.id === updated.id ? updated : it)));
      setSelectedItem(updated);
      showToast(`Analys slutförd: ${tags.length} taggar & mediakategori identifierad!`);
    } catch (err: any) {
      showToast(`Fel vid analys: ${err.message}`);
    } finally {
      setIsReindexing(false);
    }
  };

  // Add newly uploaded/indexed items (batch support)
  const handleAddNewItems = (newItems: IndexedMedia[]) => {
    setItems((prev) => [...newItems, ...prev]);
    if (newItems.length === 1) {
      showToast(`"${newItems[0].title}" indexerades med ${newItems[0].tags.length} taggar!`);
    } else {
      showToast(`${newItems.length} mediefiler indexerades framgångsrikt!`);
    }
  };

  // Delete media item
  const handleDeleteItem = (id: string) => {
    setItems((prev) => prev.filter((it) => it.id !== id));
    showToast('Mediefilen har raderats');
  };

  // Create duplicate for algorithm test
  const handleCreateTestDuplicate = () => {
    if (items.length === 0) return;
    const base = items[0];
    const duplicate: IndexedMedia = {
      ...base,
      id: 'dup-' + Date.now(),
      title: `${base.title} (Kopia)`,
      indexedAt: new Date().toISOString(),
      source: 'upload',
    };
    setItems((prev) => [duplicate, ...prev]);
    showToast(`Testdubblett skapad för "${base.title}"! Kolla under Dubbletter.`);
  };

  const handleResetToDefaults = () => {
    if (window.confirm('Vill du återställa biblioteket till standardurvalet?')) {
      setItems(INITIAL_SAMPLE_IMAGES);
      setQuery('');
      setSelectedMediaType('all');
      setSelectedCategory('all');
      showToast('Biblioteket återställt!');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col md:flex-row font-sans selection:bg-rose-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 sm:bottom-6 sm:right-6 sm:top-auto z-50 flex items-center gap-2 px-4 py-3 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm font-semibold shadow-2xl animate-fade-in backdrop-blur-md">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navigation: Desktop Sidebar (md:flex) & Mobile Tab Bar (md:hidden) */}
      <Navigation
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        duplicateCount={duplicatePairsCount}
        totalItems={items.length}
        selectedMediaType={selectedMediaType}
        onSelectMediaType={setSelectedMediaType}
        mediaCounts={mediaCounts}
        onOpenUpload={() => setIsUploadOpen(true)}
        onOpenPrompt={() => setIsPromptOpen(true)}
      />

      {/* Main App Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto pb-20 md:pb-6">
        {/* Top Mobile Bar (Visible only on mobile max-width: 768px) */}
        <header className="md:hidden sticky top-0 z-20 bg-slate-950/85 backdrop-blur-xl border-b border-slate-800/80 px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-500 flex items-center justify-center shadow">
              <ImageIcon className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-sm tracking-tight text-white">Pic Finder</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsPromptOpen(true)}
              className="p-1.5 rounded-lg bg-slate-900 text-slate-300 hover:text-white border border-slate-800"
              title="AI-Prompt"
            >
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
            </button>
            <button
              type="button"
              onClick={() => setIsUploadOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500 hover:bg-rose-600 text-white text-xs font-semibold shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Ladda upp</span>
            </button>
          </div>
        </header>

        {/* View Content Wrapper */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-2 sm:px-4 md:px-6 lg:px-8 py-3 sm:py-6">
          {/* =========================================================================
              VIEW 1: BIBLIOTEK (<section class="view view-library">)
              Responsive: 3 columns on mobile, dynamic 5-8 columns on desktop
              ========================================================================= */}
          {currentTab === 'library' && (
            <section className="view view-library space-y-4 sm:space-y-6 animate-fade-in">
              {/* Media Type Filter segmented buttons */}
              <div className="pt-1">
                <MediaTypeFilter
                  selectedMediaType={selectedMediaType}
                  onSelectMediaType={setSelectedMediaType}
                  counts={mediaCounts}
                />
              </div>

              {/* Semantic Category Pills */}
              <CategoryFilter
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
                onSelectTag={(tag) => {
                  setQuery(tag);
                  setCurrentTab('search');
                }}
                images={items}
              />

              {/* Sub-header / Status count */}
              <div className="flex items-center justify-between text-[11px] sm:text-xs text-slate-400 px-1 border-t border-slate-800/80 pt-2.5">
                <div className="flex items-center gap-2">
                  <span>
                    Visar <strong className="text-white">{filteredMedia.length}</strong> medier
                  </span>
                  {selectedMediaType !== 'all' && (
                    <span className="px-2 py-0.5 rounded-md bg-rose-500/20 text-rose-300 font-bold uppercase text-[9px] border border-rose-500/30">
                      {selectedMediaType}
                    </span>
                  )}
                  {selectedCategory !== 'all' && (
                    <span className="px-2 py-0.5 rounded-md bg-slate-800 text-emerald-300 font-medium border border-slate-700">
                      {selectedCategory}
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={handleResetToDefaults}
                  className="text-slate-500 hover:text-slate-300 transition flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span className="hidden sm:inline">Återställ</span>
                </button>
              </div>

              {/* Gallery Grid:
                  - Mobile: 3 columns (grid-cols-3 gap-1 sm:gap-2)
                  - Desktop: dynamic 5-8 columns (repeat(auto-fill, minmax(170px, 1fr)))
              */}
              {filteredMedia.length > 0 ? (
                <div className="grid grid-cols-3 md:grid-cols-[repeat(auto-fill,minmax(170px,1fr))] gap-1.5 sm:gap-3 lg:gap-4">
                  {filteredMedia.map((item) => (
                    <ImageCard
                      key={item.id}
                      result={{
                        image: item,
                        score: 100,
                        matchedTags: [],
                        matchReasons: [],
                      }}
                      isSearching={false}
                      onSelect={() => setSelectedItem(item)}
                      onTagClick={(tag) => {
                        setQuery(tag);
                        setCurrentTab('search');
                      }}
                    />
                  ))}
                </div>
              ) : (
                <div className="py-16 text-center rounded-2xl bg-slate-900/40 border border-slate-800 max-w-md mx-auto p-6 space-y-3">
                  <ImageOff className="w-10 h-10 text-slate-600 mx-auto" />
                  <h3 className="text-sm font-semibold text-white">Inga medier i detta filter</h3>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedMediaType('all');
                      setSelectedCategory('all');
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-500 hover:bg-rose-600 text-white transition"
                  >
                    Visa alla medier
                  </button>
                </div>
              )}
            </section>
          )}

          {/* =========================================================================
              VIEW 2: SÖK (<section class="view view-search">)
              Dedicated natural search view with instant semantic queries
              ========================================================================= */}
          {currentTab === 'search' && (
            <SearchView
              query={query}
              setQuery={setQuery}
              results={searchViewResults}
              totalCount={items.length}
              onSelectItem={(item) => setSelectedItem(item)}
              onTagClick={(tag) => setQuery(tag)}
            />
          )}

          {/* =========================================================================
              VIEW 3: ALBUM (<section class="view view-albums">)
              Dedicated Apple Photos style album grid
              ========================================================================= */}
          {currentTab === 'albums' && (
            <AlbumsView
              items={items}
              onSelectMediaType={(type) => {
                setSelectedMediaType(type);
                setCurrentTab('library');
              }}
              onOpenLibrary={() => setCurrentTab('library')}
              onOpenPeople={() => setCurrentTab('people')}
              onOpenDuplicates={() => setCurrentTab('duplicates')}
            />
          )}

          {/* =========================================================================
              VIEW 4: PERSONER (<section class="view view-people">)
              Smart person clusters with avatars, naming & drill-down
              ========================================================================= */}
          {currentTab === 'people' && (
            <PersonAlbumsView
              items={items}
              onSelectImage={(item) => setSelectedItem(item)}
              onTagClick={(tag) => {
                setQuery(tag);
                setCurrentTab('search');
              }}
            />
          )}

          {/* =========================================================================
              VIEW 5: DUBBLETTER (<section class="view view-duplicates">)
              Local JavaScript algorithm for duplicate detection & side-by-side cleanup
              ========================================================================= */}
          {currentTab === 'duplicates' && (
            <DuplicatesView
              items={items}
              onDeleteMedia={handleDeleteItem}
              onCreateTestDuplicate={handleCreateTestDuplicate}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <ImageDetailModal
        image={selectedItem}
        onClose={() => setSelectedItem(null)}
        onSearchTag={(tag) => {
          setQuery(tag);
          setCurrentTab('search');
        }}
        onReindex={handleReindex}
        isReindexing={isReindexing}
      />

      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onImagesIndexed={handleAddNewItems}
      />

      <PromptModal
        isOpen={isPromptOpen}
        onClose={() => setIsPromptOpen(false)}
      />
    </div>
  );
}
